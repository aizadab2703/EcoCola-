<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Путеводная звезда

Предприниматели Центральной Азии получают практическую поддержку опытных экспертов для следующего шага в бизнесе

## Метрика

Сессии с экспертами, отмеченные как завершённые, за месяц
