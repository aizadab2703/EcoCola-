import { useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { transliterateName } from "@/lib/translit";
import { toast } from "sonner";
import { Upload } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { COUNTRY_LABEL, LANG_LABEL, SECTORS, enSourceHash, formatPrice, type Mentor } from "@/lib/mentorhub";
import { translateMentorProfile } from "@/lib/translate.functions";
import { FX_CURRENCIES, convert, getFxRates, roundMoney, type FxCurrency } from "@/lib/fx.functions";
import { NativeSelect } from "@/components/native-select";

export type MentorStatus = "pending" | "active" | "paused";

const SIGNED_URL_TTL = 60 * 60 * 24 * 365; // 1 year

const schema = z.object({
  full_name: z.string().trim().min(2).max(80),
  full_name_en: z.string().trim().max(80),
  job_title: z.string().trim().max(120),
  country: z.string().trim().min(2).max(4),
  sectors: z.array(z.string().trim().min(1).max(60)).min(1),
  languages: z.array(z.string().trim().min(1).max(10)),
  short_bio_ru: z.string().trim().max(320),
  bio_ru: z.string().trim().max(2000),
  job_title_en: z.string().trim().max(200),
  short_bio_en: z.string().trim().max(600),
  bio_en: z.string().trim().max(4000),
  avatar_url: z.union([z.string().trim().url().max(1000), z.literal("")]),
  linkedin_url: z.union([z.string().trim().url().max(300), z.literal("")]),
  currency: z.enum(FX_CURRENCIES),
  // Prices are held as strings so the field can be fully cleared while typing.
  price_30: z
    .string()
    .trim()
    .regex(/^\d{0,8}$/)
    .transform((v) => (v === "" ? 0 : Number(v)))
    .pipe(z.number().int().min(0).max(10_000_000)),
  price_60: z
    .string()
    .trim()
    .regex(/^\d{0,8}$/)
    .transform((v) => (v === "" ? 0 : Number(v)))
    .pipe(z.number().int().min(0).max(10_000_000)),
  status: z.enum(["pending", "active", "paused"]),
  invite_email: z.union([z.string().trim().email().max(255), z.literal("")]),
});

type FormState = z.input<typeof schema>;

function slugify(name: string) {
  const map: Record<string, string> = {
    а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh", з: "z", и: "i", й: "i",
    к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f",
    х: "h", ц: "c", ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya",
  };
  const base = [...name.toLowerCase()]
    .map((c) => map[c] ?? c)
    .join("")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);
  return base || "mentor";
}

/** Sectors that are not part of the shared list and therefore need translating. */
function customSectors(values: string[]) {
  return values.filter((v) => !SECTORS.some((s) => s.value === v || s.ru === v || s.en === v));
}

/** EN labels for known sectors; custom ones stay as-is until translated. */
function sectorsEn(values: string[]) {
  return values.map((v) => SECTORS.find((s) => s.value === v || s.ru === v || s.en === v)?.en ?? v);
}

function emptyForm(): FormState {
  return {
    full_name: "",
    full_name_en: "",
    job_title: "",
    country: "KG",
    sectors: [],
    languages: ["ru"],
    short_bio_ru: "",
    bio_ru: "",
    job_title_en: "",
    short_bio_en: "",
    bio_en: "",
    avatar_url: "",
    linkedin_url: "",
    currency: "KGS" as FxCurrency,
    price_30: "1500",
    price_60: "2500",
    status: "pending",
    invite_email: "",
  };
}

function fromMentor(m: Mentor): FormState {
  return {
    full_name: m.full_name,
    full_name_en: m.full_name_en ?? "",
    job_title: m.job_title ?? m.headline_ru ?? "",
    country: m.country,
    sectors: m.expertise?.length ? m.expertise : m.category_slug ? [m.category_slug] : [],
    languages: m.languages?.length ? m.languages : ["ru"],
    short_bio_ru: m.short_bio_ru ?? "",
    bio_ru: m.bio_ru ?? "",
    job_title_en: m.job_title_en ?? "",
    short_bio_en: m.short_bio_en && m.short_bio_en !== m.short_bio_ru ? m.short_bio_en : "",
    bio_en: m.bio_en && m.bio_en !== m.bio_ru ? m.bio_en : "",
    avatar_url: m.avatar_url ?? "",
    linkedin_url: m.linkedin_url ?? "",
    currency: (FX_CURRENCIES as readonly string[]).includes(m.currency) ? (m.currency as FxCurrency) : "KGS",
    price_30: String(m.price_30 ?? 0),
    price_60: String(m.price_60 || m.price_per_hour),
    status: (m.status ?? (m.is_published ? "active" : "pending")) as MentorStatus,
    invite_email: m.email ?? "",
  };
}

/** Digits only, no leading zeros (a lone "0" stays), empty allowed. */
function normalizeAmount(raw: string) {
  const digits = raw.replace(/\D/g, "").slice(0, 8);
  if (digits === "") return "";
  const trimmed = digits.replace(/^0+(?=\d)/, "");
  return trimmed;
}

function Equivalents({
  amount,
  base,
  fx,
}: {
  amount: number;
  base: FxCurrency;
  fx: Awaited<ReturnType<typeof getFxRates>> | undefined;
}) {
  const { locale } = useI18n();
  if (!fx) return null;
  return (
    <p className="text-xs text-muted-foreground">
      {FX_CURRENCIES.filter((c) => c !== base)
        .map((c) => formatPrice(roundMoney(convert(amount, base, c, fx.rates), c), c, locale))
        .join(" · ")}
    </p>
  );
}

export type MentorFormPrefill = Partial<z.input<typeof schema>>;

export function MentorFormDialog({
  open,
  onOpenChange,
  mentor,
  prefill,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  mentor?: Mentor | null;
  prefill?: MentorFormPrefill | null;
}) {
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const [form, setForm] = useState<FormState>(
    mentor ? fromMentor(mentor) : { ...emptyForm(), ...(prefill ?? {}) },
  );

  const [customSector, setCustomSector] = useState("");
  const [uploading, setUploading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [translating, setTranslating] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const fetchFx = useServerFn(getFxRates);
  const translate = useServerFn(translateMentorProfile);
  const fxQ = useQuery({ queryKey: ["fx-rates"], queryFn: () => fetchFx(), staleTime: 1000 * 60 * 60 });

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function runTranslate() {
    setTranslating(true);
    try {
      const auto = await translate({
        data: {
          job_title: form.job_title,
          short_bio: form.short_bio_ru,
          bio: form.bio_ru,
          sectors: form.sectors,
        },
      });
      setForm((f) => ({
        ...f,
        full_name_en: f.full_name_en || transliterateName(f.full_name),
        job_title_en: auto.job_title_en,
        short_bio_en: auto.short_bio_en,
        bio_en: auto.bio_en,
      }));
      toast.success(t("admin.f.trDone"));
    } catch {
      toast.error(t("admin.f.trFailed"));
    }
    setTranslating(false);
  }


  function toggleSector(value: string) {
    setForm((f) => ({
      ...f,
      sectors: f.sectors.includes(value) ? f.sectors.filter((s) => s !== value) : [...f.sectors, value],
    }));
  }

  function addCustomSector() {
    const v = customSector.trim().slice(0, 60);
    if (!v || form.sectors.includes(v)) return;
    setForm((f) => ({ ...f, sectors: [...f.sectors, v] }));
    setCustomSector("");
  }

  async function uploadPhoto(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error(t("admin.f.photoType"));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error(t("admin.f.photoSize"));
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
    const path = `mentors/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("mentor-photos").upload(path, file, {
      contentType: file.type,
      upsert: false,
    });
    if (error) {
      setUploading(false);
      toast.error(error.message);
      return;
    }
    const { data, error: signErr } = await supabase.storage
      .from("mentor-photos")
      .createSignedUrl(path, SIGNED_URL_TTL);
    setUploading(false);
    if (signErr || !data?.signedUrl) {
      toast.error(signErr?.message ?? t("error"));
      return;
    }
    set("avatar_url", data.signedUrl);
    toast.success(t("admin.f.photoDone"));
  }

  async function ensureInvitation(email: string) {
    const normalized = email.trim().toLowerCase();
    const { data: existing } = await supabase
      .from("invitations")
      .select("id")
      .eq("email", normalized)
      .eq("status", "pending")
      .maybeSingle();

    if (existing) {
      // Resend: invalidate the previous token and create a fresh one.
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      const token = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
      const { error } = await supabase.from("invitations").update({ token }).eq("id", existing.id);
      return { ok: !error, error };
    }

    const { error } = await supabase.from("invitations").insert({ email: normalized, role: "mentor" });
    return { ok: !error, error };
  }

  async function save() {
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? t("error"));
      return;
    }
    const v = parsed.data;
    setBusy(true);

    const normalizedEmail = v.invite_email ? v.invite_email.trim().toLowerCase() : null;

    if (normalizedEmail) {
      let query = supabase.from("mentors").select("id").ilike("email", normalizedEmail);
      if (mentor) query = query.neq("id", mentor.id);
      const { data: existing, error: dupErr } = await query.maybeSingle();
      if (dupErr) {
        setBusy(false);
        toast.error(dupErr.message);
        return;
      }
      if (existing) {
        setBusy(false);
        toast.error(t("admin.emailExists"));
        return;
      }
    }

    // Reuse admin-edited EN text; auto-translate whatever is still missing.
    let en = {
      job_title_en: v.job_title_en,
      short_bio_en: v.short_bio_en,
      bio_en: v.bio_en,
      sectors_en: sectorsEn(v.sectors),
    };
    const needsAuto =
      (v.job_title && !en.job_title_en) ||
      (v.short_bio_ru && !en.short_bio_en) ||
      (v.bio_ru && !en.bio_en) ||
      customSectors(v.sectors).length > 0;
    if (needsAuto) {
      try {
        const auto = await translate({
          data: {
            job_title: v.job_title,
            short_bio: v.short_bio_ru,
            bio: v.bio_ru,
            sectors: v.sectors,
          },
        });
        en = {
          job_title_en: en.job_title_en || auto.job_title_en,
          short_bio_en: en.short_bio_en || auto.short_bio_en,
          bio_en: en.bio_en || auto.bio_en,
          sectors_en: auto.sectors_en,
        };
      } catch {
        toast.error(t("admin.f.trFailed"));
      }
    }

    const known = SECTORS.find((s) => s.value === v.sectors[0] || s[locale] === v.sectors[0]);
    const payload = {
      full_name: v.full_name,
      full_name_en: v.full_name_en || transliterateName(v.full_name),
      job_title: v.job_title,
      country: v.country.toUpperCase(),
      category_slug: known?.value ?? slugify(v.sectors[0] ?? "other"),
      expertise: v.sectors,
      languages: v.languages.length ? v.languages : ["ru"],
      short_bio_ru: v.short_bio_ru,
      short_bio_en: en.short_bio_en || v.short_bio_ru,
      bio_ru: v.bio_ru,
      bio_en: en.bio_en || v.bio_ru,
      job_title_en: en.job_title_en || v.job_title,
      expertise_en: en.sectors_en,
      en_source_hash: enSourceHash([v.job_title, v.short_bio_ru, v.bio_ru, v.sectors.join(",")]),
      // Job title is shown on its own; keep the legacy headline field only
      // when the admin has not provided a job title.
      headline_ru: v.job_title ? "" : (mentor?.headline_ru ?? ""),
      headline_en: v.job_title ? "" : (mentor?.headline_en ?? ""),
      avatar_url: v.avatar_url || null,
      linkedin_url: v.linkedin_url || null,
      currency: v.currency,
      price_30: v.price_30,
      price_60: v.price_60,
      price_per_hour: v.price_60,
      status: v.status,
      email: normalizedEmail,
    };

    const { error } = mentor
      ? await supabase.from("mentors").update(payload).eq("id", mentor.id)
      : await supabase
          .from("mentors")
          .insert({ ...payload, slug: `${slugify(v.full_name)}-${Math.random().toString(36).slice(2, 6)}` });

    if (error) {
      setBusy(false);
      toast.error(error.message);
      return;
    }

    const emailChanged =
      normalizedEmail && normalizedEmail !== (mentor?.email ?? "").toLowerCase();
    if (emailChanged) {
      const { ok, error: invErr } = await ensureInvitation(normalizedEmail);
      if (invErr) toast.error(invErr.message);
      else if (ok) toast.success(t("admin.inviteSent"));
    }

    setBusy(false);
    qc.invalidateQueries({ queryKey: ["admin-mentors"] });
    qc.invalidateQueries({ queryKey: ["mentors"] });
    qc.invalidateQueries({ queryKey: ["admin-invites"] });
    toast.success(t("admin.saved"));
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] w-[calc(100vw-2rem)] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">
            {mentor ? t("admin.editMentor") : t("admin.newMentor")}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t("admin.f.photo")} className="sm:col-span-2">
            <div className="flex flex-wrap items-center gap-3">
              {form.avatar_url ? (
                <img
                  src={form.avatar_url}
                  alt={form.full_name || "avatar"}
                  className="h-16 w-16 shrink-0 rounded-2xl object-cover"
                />
              ) : (
                <div className="h-16 w-16 shrink-0 rounded-2xl bg-secondary" />
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void uploadPhoto(f);
                  e.target.value = "";
                }}
              />
              <Button type="button" variant="outline" disabled={uploading} onClick={() => fileRef.current?.click()}>
                <Upload className="mr-1.5 h-4 w-4" />
                {uploading ? t("admin.f.photoUploading") : t("admin.f.photoUpload")}
              </Button>
              {form.avatar_url && (
                <Button type="button" variant="ghost" onClick={() => set("avatar_url", "")}>
                  {t("admin.delete")}
                </Button>
              )}
            </div>
            <Input
              value={form.avatar_url}
              maxLength={1000}
              placeholder={t("admin.f.photoUrlOptional")}
              onChange={(e) => set("avatar_url", e.target.value)}
            />
          </Field>

          <Field label={t("admin.f.name")}>
            <Input value={form.full_name} maxLength={80} onChange={(e) => set("full_name", e.target.value)} />
          </Field>
          <Field label={t("admin.f.jobTitle")}>
            <Input
              value={form.job_title}
              maxLength={120}
              placeholder={t("admin.f.jobTitlePh")}
              onChange={(e) => set("job_title", e.target.value)}
            />
          </Field>

          <Field label={t("admin.f.country")}>
            <NativeSelect
              value={form.country}
              onChange={(e) => set("country", e.target.value)}
            >
              {Object.keys(COUNTRY_LABEL).map((c) => (
                <option key={c} value={c}>
                  {COUNTRY_LABEL[c]?.[locale] ?? c}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <Field label={t("admin.f.status")}>
            <NativeSelect
              value={form.status}
              onChange={(e) => set("status", e.target.value as MentorStatus)}
            >
              <option value="pending">{t("status.pending")}</option>
              <option value="active">{t("status.active")}</option>
              <option value="paused">{t("status.paused")}</option>
            </NativeSelect>
          </Field>

          <Field label={t("admin.f.languages")} className="sm:col-span-2">
            <div className="flex flex-wrap gap-2">
              {Object.keys(LANG_LABEL).map((code) => {
                const on = form.languages.includes(code);
                return (
                  <button
                    key={code}
                    type="button"
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        languages: f.languages.includes(code)
                          ? f.languages.filter((l) => l !== code)
                          : [...f.languages, code],
                      }))
                    }
                    className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                      on
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background hover:border-primary"
                    }`}
                  >
                    {LANG_LABEL[code]![locale]}
                  </button>
                );
              })}
            </div>
          </Field>

          <Field label={t("admin.f.sectors")} className="sm:col-span-2">
            <div className="flex flex-wrap gap-2">
              {SECTORS.map((s) => {
                const on = form.sectors.includes(s.value) || form.sectors.includes(s[locale]);
                return (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => toggleSector(s.value)}
                    className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                      on
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-background hover:border-primary"
                    }`}
                  >
                    {s[locale]}
                  </button>
                );
              })}
              {form.sectors
                .filter((v) => !SECTORS.some((s) => s.value === v || s[locale] === v))
                .map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => toggleSector(v)}
                    className="rounded-full border border-primary bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground"
                  >
                    {v} ×
                  </button>
                ))}
            </div>
            <div className="mt-2 flex gap-2">
              <Input
                value={customSector}
                maxLength={60}
                placeholder={t("admin.f.sectorCustom")}
                onChange={(e) => setCustomSector(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addCustomSector();
                  }
                }}
              />
              <Button type="button" variant="outline" onClick={addCustomSector}>
                +
              </Button>
            </div>
          </Field>

          <Field label={t("admin.f.shortBio")} className="sm:col-span-2">
            <Textarea
              rows={3}
              value={form.short_bio_ru}
              maxLength={320}
              placeholder={t("admin.f.shortBioPh")}
              onChange={(e) => set("short_bio_ru", e.target.value)}
            />
            <p className="text-xs text-muted-foreground">{form.short_bio_ru.length}/320</p>
          </Field>

          <Field label={t("admin.f.bio")} className="sm:col-span-2">
            <Textarea rows={5} value={form.bio_ru} maxLength={2000} onChange={(e) => set("bio_ru", e.target.value)} />
          </Field>

          <div className="rounded-xl border border-border p-4 sm:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm font-semibold">{t("admin.f.enTitle")}</p>
                <p className="text-xs text-muted-foreground">{t("admin.f.enHint")}</p>
              </div>
              <Button type="button" variant="outline" disabled={translating} onClick={runTranslate}>
                {translating ? t("admin.f.trBusy") : t("admin.f.translate")}
              </Button>
            </div>
            <div className="mt-3 space-y-3">
              <Field label={`${t("admin.f.name")} (EN)`}>
                <Input
                  value={form.full_name_en}
                  maxLength={80}
                  placeholder={transliterateName(form.full_name)}
                  onChange={(e) => set("full_name_en", e.target.value)}
                />
              </Field>
              <Field label={`${t("admin.f.jobTitle")} (EN)`}>
                <Input
                  value={form.job_title_en}
                  maxLength={200}
                  onChange={(e) => set("job_title_en", e.target.value)}
                />
              </Field>
              <Field label={`${t("admin.f.shortBio")} (EN)`}>
                <Textarea
                  rows={3}
                  value={form.short_bio_en}
                  maxLength={600}
                  onChange={(e) => set("short_bio_en", e.target.value)}
                />
              </Field>
              <Field label={`${t("admin.f.bio")} (EN)`}>
                <Textarea
                  rows={5}
                  value={form.bio_en}
                  maxLength={4000}
                  onChange={(e) => set("bio_en", e.target.value)}
                />
              </Field>
            </div>
          </div>


          <Field label="LinkedIn" className="sm:col-span-2">
            <Input
              value={form.linkedin_url}
              maxLength={300}
              placeholder="https://linkedin.com/in/…"
              onChange={(e) => set("linkedin_url", e.target.value)}
            />
          </Field>

          <Field label={t("admin.f.currency")} className="sm:col-span-2">
            <NativeSelect
              value={form.currency}
              onChange={(e) => set("currency", e.target.value as FxCurrency)}
              wrapperClassName="sm:w-56"
            >
              {FX_CURRENCIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </NativeSelect>
          </Field>

          <Field label={t("admin.f.price30")}>
            <Input
              inputMode="numeric"
              maxLength={8}
              value={form.price_30}
              onChange={(e) => set("price_30", normalizeAmount(e.target.value))}
            />
            <Equivalents amount={Number(form.price_30) || 0} base={form.currency} fx={fxQ.data} />
          </Field>
          <Field label={t("admin.f.price60")}>
            <Input
              inputMode="numeric"
              maxLength={8}
              value={form.price_60}
              onChange={(e) => set("price_60", normalizeAmount(e.target.value))}
            />
            <Equivalents amount={Number(form.price_60) || 0} base={form.currency} fx={fxQ.data} />
          </Field>

          <p className="text-xs text-muted-foreground sm:col-span-2">
            {fxQ.data
              ? `${t(fxQ.data.live ? "admin.f.fxLive" : "admin.f.fxFallback")} · ${fxQ.data.source} · ${fxQ.data.date}`
              : t("admin.f.fxLoading")}
          </p>

          <Field label={t("admin.f.invite")} className="sm:col-span-2">
            <Input
              type="email"
              maxLength={255}
              value={form.invite_email}
              placeholder="mentor@example.com"
              onChange={(e) => set("invite_email", e.target.value)}
            />
          </Field>
        </div>

        <DialogFooter className="mt-2 gap-2 sm:gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t("admin.cancel")}
          </Button>
          <Button disabled={busy || uploading} onClick={save} className="bg-gradient-brand text-primary-foreground">
            {t("admin.save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
