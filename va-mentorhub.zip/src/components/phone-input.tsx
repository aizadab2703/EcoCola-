import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { getVisitorCountry } from "@/lib/geo.functions";
import { useI18n } from "@/lib/i18n";
import { NativeSelect } from "@/components/native-select";

export type DialCountry = { code: string; dial: string; ru: string; en: string };

/** Central Asia first, then other common origins for our audience. */
export const DIAL_COUNTRIES: DialCountry[] = [
  { code: "KG", dial: "+996", ru: "Кыргызстан", en: "Kyrgyzstan" },
  { code: "KZ", dial: "+7", ru: "Казахстан", en: "Kazakhstan" },
  { code: "UZ", dial: "+998", ru: "Узбекистан", en: "Uzbekistan" },
  { code: "TJ", dial: "+992", ru: "Таджикистан", en: "Tajikistan" },
  { code: "TM", dial: "+993", ru: "Туркменистан", en: "Turkmenistan" },
  { code: "RU", dial: "+7", ru: "Россия", en: "Russia" },
  { code: "AZ", dial: "+994", ru: "Азербайджан", en: "Azerbaijan" },
  { code: "GE", dial: "+995", ru: "Грузия", en: "Georgia" },
  { code: "AM", dial: "+374", ru: "Армения", en: "Armenia" },
  { code: "BY", dial: "+375", ru: "Беларусь", en: "Belarus" },
  { code: "TR", dial: "+90", ru: "Турция", en: "Türkiye" },
  { code: "AE", dial: "+971", ru: "ОАЭ", en: "UAE" },
  { code: "PK", dial: "+92", ru: "Пакистан", en: "Pakistan" },
  { code: "GB", dial: "+44", ru: "Великобритания", en: "United Kingdom" },
  { code: "DE", dial: "+49", ru: "Германия", en: "Germany" },
  { code: "US", dial: "+1", ru: "США", en: "United States" },
  { code: "IN", dial: "+91", ru: "Индия", en: "India" },
  { code: "CN", dial: "+86", ru: "Китай", en: "China" },
];

const FALLBACK_CODE = "US";

function byCode(code: string) {
  return DIAL_COUNTRIES.find((c) => c.code === code) ?? DIAL_COUNTRIES.find((c) => c.code === FALLBACK_CODE)!;
}

/** Detect the visitor country (server header first, browser locale as backup). */
export function useVisitorPhoneCountry() {
  const [code, setCode] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    void (async () => {
      let country: string | null = null;
      try {
        country = (await getVisitorCountry()).country;
      } catch {
        country = null;
      }
      if (!country) {
        try {
          country = new Intl.Locale(navigator.language).maximize().region ?? null;
        } catch {
          country = null;
        }
      }
      const upper = (country ?? "").toUpperCase();
      const match = DIAL_COUNTRIES.find((c) => c.code === upper);
      if (alive) setCode(match ? match.code : FALLBACK_CODE);
    })();
    return () => {
      alive = false;
    };
  }, []);

  return code;
}

/** Split a stored full phone number into a country choice and the local part. */
function parsePhone(value: string, fallbackCode: string) {
  const trimmed = (value ?? "").trim();
  if (trimmed.startsWith("+")) {
    const sorted = [...DIAL_COUNTRIES].sort((a, b) => b.dial.length - a.dial.length);
    const hit = sorted.find((c) => trimmed.startsWith(c.dial));
    if (hit) return { code: hit.code, local: trimmed.slice(hit.dial.length).trim() };
  }
  return { code: fallbackCode, local: trimmed };
}

export function PhoneInput({
  value,
  onChange,
  id,
  placeholder = "700 123 456",
  className = "",
}: {
  value: string;
  onChange: (fullNumber: string) => void;
  id?: string;
  placeholder?: string;
  className?: string;
}) {
  const { locale } = useI18n();
  const detected = useVisitorPhoneCountry();
  const [country, setCountry] = useState<string | null>(null);
  const [touchedCountry, setTouchedCountry] = useState(false);

  const parsed = useMemo(() => parsePhone(value, country ?? detected ?? FALLBACK_CODE), [value, country, detected]);
  const activeCode = touchedCountry ? (country ?? parsed.code) : parsed.code;
  const active = byCode(activeCode);

  // Prefill the dial code once geolocation resolves and the user hasn't typed a code yet.
  useEffect(() => {
    if (!detected || touchedCountry) return;
    if (value.trim().startsWith("+")) return;
    setCountry(detected);
    const local = value.trim();
    onChange(local ? `${byCode(detected).dial} ${local}` : byCode(detected).dial);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detected]);

  function setDial(code: string) {
    setCountry(code);
    setTouchedCountry(true);
    const local = parsed.local;
    onChange(local ? `${byCode(code).dial} ${local}` : byCode(code).dial);
  }

  function setLocal(raw: string) {
    const local = raw.replace(/[^\d\s()-]/g, "").slice(0, 20);
    onChange(local ? `${active.dial} ${local}` : active.dial);
  }

  return (
    <div className={`flex gap-2 ${className}`}>
      <NativeSelect
        value={active.code}
        onChange={(e) => setDial(e.target.value)}
        aria-label={locale === "ru" ? "Код страны" : "Country code"}
        wrapperClassName="w-[7.5rem] shrink-0 sm:w-40"
      >
        {DIAL_COUNTRIES.map((c) => (
          <option key={c.code} value={c.code}>
            {c.dial} {c[locale]}
          </option>
        ))}
      </NativeSelect>
      <Input
        id={id}
        type="tel"
        inputMode="tel"
        autoComplete="tel-national"
        value={parsed.local}
        placeholder={placeholder}
        onChange={(e) => setLocal(e.target.value)}
      />
    </div>
  );
}
