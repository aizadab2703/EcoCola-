import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Menu, Moon, Sun, X } from "lucide-react";
import { Logo } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { useRoles, useSession, signOutEverywhere } from "@/lib/session";

function LocaleSwitch() {
  const { locale, setLocale } = useI18n();
  return (
    <div className="inline-flex overflow-hidden rounded-full border border-border bg-card p-0.5 text-xs font-semibold">
      {(["ru", "en"] as const).map((l) => (
        <button
          key={l}
          onClick={() => setLocale(l)}
          className={`rounded-full px-2.5 py-1 uppercase transition-colors duration-200 ${
            locale === l ? "bg-gradient-brand text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

function ThemeToggle() {
  const { t } = useI18n();
  const { theme, toggleTheme } = useTheme();
  const label = theme === "dark" ? t("nav.themeLight") : t("nav.themeDark");
  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={label}
      title={label}
      className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card text-muted-foreground transition-colors duration-200 hover:text-foreground"
    >
      {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </button>
  );
}

export function SiteHeader() {
  const { t } = useI18n();
  const { user } = useSession();
  const { isAdmin, isMentor } = useRoles();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const links = [
    { to: "/mentors" as const, label: t("nav.mentors") },
    { to: "/become-a-mentor" as const, label: t("nav.become") },
  ];

  async function handleSignOut() {
    await signOutEverywhere(qc);
    await navigate({ to: "/", replace: true });
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/85 backdrop-blur-xl">
      <div className="mx-auto flex min-h-20 max-w-6xl items-center gap-4 px-4 py-4">
        <Logo className="h-20 sm:h-24" />

        <nav className="ml-auto hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition-colors duration-200 hover:bg-secondary hover:text-foreground"
              activeProps={{ className: "text-foreground bg-secondary" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2 md:ml-0">
          <ThemeToggle />
          <LocaleSwitch />
          {user ? (
            <div className="hidden items-center gap-2 md:flex">
              <Button asChild variant="ghost" size="sm">
                <Link to="/dashboard">{t("nav.dashboard")}</Link>
              </Button>
              {isMentor && (
                <Button asChild variant="ghost" size="sm">
                  <Link to="/mentor-cabinet">{t("nav.mentorCabinet")}</Link>
                </Button>
              )}
              {isAdmin && (
                <Button asChild variant="ghost" size="sm">
                  <Link to="/admin">{t("nav.admin")}</Link>
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={handleSignOut}>
                {t("nav.signout")}
              </Button>
            </div>
          ) : (
            <Button asChild size="sm" className="hidden bg-gradient-brand text-primary-foreground md:inline-flex">
              <Link to="/auth">{t("nav.signin")}</Link>
            </Button>
          )}
          <button
            className="grid h-9 w-9 place-items-center rounded-full border border-border md:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-label="Menu"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-border bg-background px-4 py-3 md:hidden">
          <div className="flex flex-col gap-1">
            {links.map((l) => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm">
                {l.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm">
                  {t("nav.dashboard")}
                </Link>
                {isMentor && (
                  <Link to="/mentor-cabinet" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm">
                    {t("nav.mentorCabinet")}
                  </Link>
                )}
                {isAdmin && (
                  <Link to="/admin" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm">
                    {t("nav.admin")}
                  </Link>
                )}
                <button onClick={handleSignOut} className="rounded-lg px-3 py-2 text-left text-sm">
                  {t("nav.signout")}
                </button>
              </>
            ) : (
              <Link to="/auth" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm font-semibold">
                {t("nav.signin")}
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  const { t } = useI18n();
  return (
    <footer className="mt-24 border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo className="h-24" />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">{t("footer.tagline")}</p>
        </div>
        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wider">{t("footer.product")}</h3>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/mentors" className="transition-colors hover:text-primary">
                {t("nav.mentors")}
              </Link>
            </li>
            <li>
              <Link to="/become-a-mentor" className="transition-colors hover:text-primary">
                {t("nav.become")}
              </Link>
            </li>
            <li>
              <Link to="/dashboard" className="transition-colors hover:text-primary">
                {t("nav.dashboard")}
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wider">{t("footer.legal")}</h3>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/offer" className="transition-colors hover:text-primary">
                {t("offer.title")}
              </Link>
            </li>
            <li>
              <a href="mailto:hello@virtualaccelerate.org" className="transition-colors hover:text-primary">
                hello@virtualaccelerate.org
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} VirtualAccelerate MentorHub. {t("footer.rights")}
      </div>
    </footer>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}
