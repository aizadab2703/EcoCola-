import { Link } from "@tanstack/react-router";
import { Star, MapPin } from "lucide-react";
import { Avatar } from "@/components/brand";
import { useI18n } from "@/lib/i18n";
import { COUNTRY_LABEL, localized, mentorJobTitle, mentorName, mentorSectors, type Mentor } from "@/lib/mentorhub";
import { useCurrency } from "@/lib/currency";

export function MentorCard({ mentor }: { mentor: Mentor }) {
  const { t, locale } = useI18n();
  const { display } = useCurrency();
  const country = COUNTRY_LABEL[mentor.country]?.[locale] ?? mentor.country;
  const row = mentor as unknown as Record<string, unknown>;

  // Show the job title once, under the name. Fall back to the headline for
  // legacy/demo mentors so the card always has a meaningful subtitle.
  const headline = localized(row, "headline", locale);
  const jobTitle = mentorJobTitle(mentor, locale);
  const subtitle = jobTitle && jobTitle !== headline ? jobTitle : headline;

  const fullBio = localized(row, "bio", locale) || headline;
  // Short summary is what the card shows by default (incl. mobile);
  // fall back to a trimmed full bio for mentors saved before this field existed.
  const shortBio =
    localized(row, "short_bio", locale) ||
    (fullBio.length > 160 ? `${fullBio.slice(0, 157).trimEnd()}…` : fullBio);

  return (
    <Link
      to="/mentors/$slug"
      params={{ slug: mentor.slug }}
      className="lift-hover group flex h-full flex-col rounded-2xl border border-border bg-card p-5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
    >
      <div className="flex items-start gap-4">
        <Avatar name={mentorName(mentor, locale)} size={56} src={mentor.avatar_url} />
        <div className="min-w-0">
          <h3 className="truncate font-display text-base font-semibold">{mentorName(mentor, locale)}</h3>
          {subtitle ? <p className="truncate text-xs font-medium text-primary">{subtitle}</p> : null}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {mentorSectors(mentor, locale).slice(0, 3).map((e) => (
          <span key={e} className="rounded-full bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground">
            {e}
          </span>
        ))}
      </div>

      <div className="relative mt-3 flex flex-1 flex-col overflow-hidden">
        {shortBio ? (
          <p className="line-clamp-3 text-sm text-muted-foreground md:line-clamp-2">{shortBio}</p>
        ) : null}

        <div className="mt-auto flex items-end justify-between pt-4 text-xs text-muted-foreground">
          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <Star className="h-3.5 w-3.5 fill-primary text-primary" />
              <span className="font-semibold text-foreground">{mentor.rating.toFixed(1)}</span>
              <span>
                · {mentor.reviews_count} {t("mentor.reviews")}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" />
              {mentor.city ? `${mentor.city}, ` : ""}
              {country}
            </div>
          </div>
          <div className="text-right">
            <div className="font-display text-lg font-semibold text-brand-blue-deep">
              {display(mentor.price_60 || mentor.price_per_hour, mentor.currency, locale)}
            </div>
            <div className="text-xs text-muted-foreground">{t("mentor.perHour")}</div>
          </div>
        </div>

        {/* Desktop hover reveal: full bio, no grid jump, no overlap beyond card */}
        <div className="absolute inset-0 hidden flex-col justify-start overflow-y-auto rounded-xl bg-card p-2 opacity-0 translate-y-2 transition-all duration-300 md:flex md:group-hover:opacity-100 md:group-hover:translate-y-0 md:group-focus-within:opacity-100 md:group-focus-within:translate-y-0">
          <p className="line-clamp-[6] text-sm leading-relaxed text-muted-foreground">
            {fullBio || t("catalog.emptyBio")}
          </p>
          <span className="mt-2 text-xs font-medium text-primary">{t("catalog.openProfile")}</span>
        </div>
      </div>
    </Link>
  );
}
