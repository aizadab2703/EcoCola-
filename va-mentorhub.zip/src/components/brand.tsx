import { Link } from "@tanstack/react-router";
import logo from "@/assets/virtual-accelerate-experts-hub-logo.png.asset.json";

export function Logo({ className = "h-10" }: { className?: string }) {
  return (
    <Link to="/" className="inline-flex items-center" aria-label="Virtual Accelerate Experts Hub">
      <img
        src={logo.url}
        alt="Virtual Accelerate Experts Hub"
        className={`${className} w-auto shrink-0 object-contain transition-transform duration-300 hover:scale-[1.03]`}
      />
    </Link>
  );
}

export function Avatar({ name, size = 56, src }: { name: string; size?: number; src?: string | null | undefined }) {
  if (src) {
    return (
      <img
        src={src}
        alt={name}
        loading="lazy"
        className="shrink-0 rounded-2xl object-cover"
        style={{ width: size, height: size }}
      />
    );
  }
  const initials = name
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0] ?? "")
    .join("")
    .toUpperCase();
  const hue = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % 2;
  return (
    <span
      className="grid shrink-0 place-items-center rounded-2xl font-display font-semibold text-primary-foreground"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.34,
        background:
          hue === 0
            ? "linear-gradient(135deg, var(--primary), var(--brand-blue))"
            : "linear-gradient(135deg, var(--brand-blue), var(--primary))",
      }}
      aria-hidden
    >
      {initials}
    </span>
  );
}
