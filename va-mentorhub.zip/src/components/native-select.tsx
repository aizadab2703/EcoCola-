import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Native <select> with consistent styling and a visible chevron that keeps
 * comfortable spacing from the right edge.
 */
export function NativeSelect({
  className,
  wrapperClassName,
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & { wrapperClassName?: string }) {
  return (
    <span className={cn("relative inline-flex w-full items-center", wrapperClassName)}>
      <select
        {...props}
        className={cn(
          "h-10 w-full appearance-none rounded-lg border border-border bg-background py-2 pl-3 pr-10 text-sm",
          "outline-none transition-colors focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30",
          className,
        )}
      >
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 h-4 w-4 shrink-0 text-muted-foreground" />
    </span>
  );
}
