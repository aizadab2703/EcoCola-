import { useEffect, useRef, useState, type ReactNode } from "react";

/** Scroll-triggered reveal. */
export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "-8% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`${shown ? "reveal-in" : "reveal-init"} ${className}`}
      style={shown ? { transitionDelay: `${delay}ms` } : undefined}
    >
      {children}
    </div>
  );
}

/** Hero typewriter cycling through tracks. */
export function Typewriter({ words, className = "" }: { words: string[]; className?: string }) {
  const [index, setIndex] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[index % words.length] ?? "";
    const done = !deleting && text === word;
    const empty = deleting && text === "";

    const timeout = window.setTimeout(
      () => {
        if (done) {
          setDeleting(true);
          return;
        }
        if (empty) {
          setDeleting(false);
          setIndex((i) => (i + 1) % words.length);
          return;
        }
        setText(deleting ? word.slice(0, text.length - 1) : word.slice(0, text.length + 1));
      },
      done ? 1600 : deleting ? 38 : 72,
    );
    return () => window.clearTimeout(timeout);
  }, [text, deleting, index, words]);

  return (
    <span className={className}>
      <span className="text-gradient-brand">{text}</span>
      <i className="caret-blink" />
    </span>
  );
}

/** Counter that springs up when scrolled into view. */
export function CounterUp({
  to,
  suffix = "",
  decimals = 0,
  duration = 1400,
}: {
  to: number;
  suffix?: string;
  decimals?: number;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    const io = new IntersectionObserver(([entry]) => {
      if (!entry?.isIntersecting) return;
      io.disconnect();
      const start = performance.now();
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - p, 3);
        setValue(to * eased);
        if (p < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [to, duration]);

  return (
    <span ref={ref} className="counter-spring tabular-nums">
      {value.toFixed(decimals)}
      {suffix}
    </span>
  );
}

/** Orbital mentor visualisation for the hero. */
export function MentorOrbit({ names }: { names: string[] }) {
  const items = names.slice(0, 6);
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[420px]">
      <div className="aurora left-6 top-10 h-40 w-40 bg-primary/60" />
      <div className="aurora bottom-6 right-4 h-44 w-44 bg-brand-blue/50" style={{ animationDelay: "-6s" }} />

      <div className="absolute inset-[12%] rounded-full border border-primary/25" />
      <div className="absolute inset-[26%] rounded-full border border-brand-blue/25" />

      <div className="orbit-ring absolute inset-0">
        {items.slice(0, 3).map((name, i) => (
          <OrbitDot key={name} name={name} angle={(360 / 3) * i} radius={44} />
        ))}
      </div>
      <div className="orbit-ring-reverse absolute inset-[14%]">
        {items.slice(3).map((name, i) => (
          <OrbitDot key={name} name={name} angle={(360 / 3) * i + 60} radius={44} small />
        ))}
      </div>

      <div className="absolute inset-[36%] grid place-items-center rounded-full bg-gradient-brand text-center text-primary-foreground shadow-glow">
        <div>
          <div className="font-display text-2xl font-bold leading-none">VA</div>
          <div className="mt-1 text-[10px] uppercase tracking-[0.18em] opacity-90">MentorHub</div>
        </div>
      </div>
    </div>
  );
}

function OrbitDot({
  name,
  angle,
  radius,
  small = false,
}: {
  name: string;
  angle: number;
  radius: number;
  small?: boolean;
}) {
  const initials = name
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0] ?? "")
    .join("")
    .toUpperCase();
  return (
    <span
      className="absolute left-1/2 top-1/2"
      style={{ transform: `rotate(${angle}deg) translate(${radius}%) rotate(-${angle}deg)` }}
    >
      <span
        className={`grid -translate-x-1/2 -translate-y-1/2 place-items-center rounded-2xl border border-border bg-card font-display font-semibold text-foreground shadow-lift ${
          small ? "h-11 w-11 text-xs" : "h-14 w-14 text-sm"
        }`}
      >
        {initials}
      </span>
    </span>
  );
}
