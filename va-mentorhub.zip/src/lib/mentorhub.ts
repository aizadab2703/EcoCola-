import { supabase } from "@/integrations/supabase/client";
import { transliterateName } from "@/lib/translit";
import type { Locale } from "@/lib/i18n";

export type Mentor = {
  id: string;
  user_id: string | null;
  email?: string | null;
  slug: string;
  full_name: string;
  headline_ru: string;
  headline_en: string;
  bio_ru: string;
  bio_en: string;
  short_bio_ru?: string;
  short_bio_en?: string;

  country: string;
  city: string | null;
  languages: string[];
  expertise: string[];
  category_slug: string;
  price_per_hour: number;
  currency: string;
  rating: number;
  reviews_count: number;
  sessions_count: number;
  is_published: boolean;
  avatar_url?: string | null;
  linkedin_url?: string | null;
  price_30?: number;
  price_60?: number;
  status?: "pending" | "active" | "paused";
  job_title?: string;
  full_name_en?: string | null;
  job_title_en?: string | null;
  expertise_en?: string[] | null;
  en_source_hash?: string | null;
};

/** Stable fingerprint of the Russian source copy, used to know when EN is stale. */
export function enSourceHash(parts: (string | undefined | null)[]) {
  const s = parts.map((p) => (p ?? "").trim()).join("|");
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return `${s.length}-${(h >>> 0).toString(36)}`;
}

/** Mentor name in the current locale: Latin spelling for EN visitors. */
export function mentorName(m: Pick<Mentor, "full_name" | "full_name_en">, locale: Locale) {
  if (locale === "en") return m.full_name_en?.trim() || transliterateName(m.full_name);
  return m.full_name;
}

/** Job title in the current locale (English translation when available). */
export function mentorJobTitle(m: Pick<Mentor, "job_title" | "job_title_en">, locale: Locale) {
  if (locale === "en" && m.job_title_en) return m.job_title_en;
  return m.job_title ?? "";
}

/** Sector labels in the current locale: known sectors are mapped, custom ones use stored EN. */
export function mentorSectors(
  m: Pick<Mentor, "expertise" | "expertise_en">,
  locale: Locale,
): string[] {
  return (m.expertise ?? []).map((value, i) => {
    const known = SECTORS.find((s) => s.value === value || s.ru === value || s.en === value);
    if (known) return known[locale];
    if (locale === "en") return m.expertise_en?.[i] || value;
    return value;
  });
}


/** Kept in sync with the clickable category tags on the landing page. */
export const SECTORS: { value: string; ru: string; en: string }[] = [
  { value: "startup", ru: "Стартапы и венчур", en: "Startups & Venture" },
  { value: "product", ru: "Продукт и UX", en: "Product & UX" },
  { value: "tech", ru: "Технологии и инженерия", en: "Tech & Engineering" },
  { value: "marketing", ru: "Маркетинг и рост", en: "Marketing & Growth" },
  { value: "finance", ru: "Финансы и инвестиции", en: "Finance & Investment" },
  { value: "career", ru: "Карьера и лидерство", en: "Career & Leadership" },
  { value: "data", ru: "Данные и AI", en: "Data & AI" },
  { value: "legal", ru: "Право и комплаенс", en: "Legal & Compliance" },
  { value: "green", ru: "Зелёный бизнес и ESG", en: "Green Business & ESG" },
];


export type Category = {
  slug: string;
  name_ru: string;
  name_en: string;
  icon: string | null;
  sort_order: number;
};

export const COUNTRY_LABEL: Record<string, { ru: string; en: string }> = {
  KG: { ru: "Кыргызстан", en: "Kyrgyzstan" },
  KZ: { ru: "Казахстан", en: "Kazakhstan" },
  UZ: { ru: "Узбекистан", en: "Uzbekistan" },
  TJ: { ru: "Таджикистан", en: "Tajikistan" },
  TM: { ru: "Туркменистан", en: "Turkmenistan" },
  PK: { ru: "Пакистан", en: "Pakistan" },
};

export const LANG_LABEL: Record<string, { ru: string; en: string }> = {
  ru: { ru: "Русский", en: "Russian" },
  en: { ru: "Английский", en: "English" },
  kk: { ru: "Казахский", en: "Kazakh" },
  ky: { ru: "Кыргызский", en: "Kyrgyz" },
  uz: { ru: "Узбекский", en: "Uzbek" },
};

export function localized<T extends Record<string, unknown>>(row: T, base: string, locale: Locale): string {
  return String(row[`${base}_${locale}`] ?? row[`${base}_ru`] ?? "");
}

export function formatPrice(amount: number, currency: string, locale: Locale) {
  return new Intl.NumberFormat(locale === "ru" ? "ru-RU" : "en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDateTime(iso: string, locale: Locale) {
  return new Intl.DateTimeFormat(locale === "ru" ? "ru-RU" : "en-US", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(iso));
}

export async function fetchMentors() {
  const { data, error } = await supabase
    .from("mentors")
    .select("*")
    .eq("is_published", true)
    .order("rating", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Mentor[];
}

export async function fetchCategories() {
  const { data, error } = await supabase.from("categories").select("*").order("sort_order");
  if (error) throw error;
  return (data ?? []) as unknown as Category[];
}

/* ------------------------------------------------------------------ *
 * Integration points (MVP stubs)
 * ------------------------------------------------------------------ */

/**
 * Google Meet integration point.
 * MVP: a deterministic demo room link is generated on payment confirmation.
 * Production: swap this for a Google Calendar `conferenceData` insert
 * (calendar.events.insert with conferenceDataVersion=1) executed in a
 * server function with the mentor's connected Google account.
 */
export function createDemoMeetLink(bookingId: string) {
  const code = bookingId.replace(/-/g, "").slice(0, 10);
  return `https://meet.google.com/lookup/va-${code}`;
}

/**
 * Google Calendar integration point.
 * MVP: renders a "add to calendar" template URL that works without OAuth.
 * Production: replace with events.insert on both participants' calendars.
 */
export function googleCalendarUrl(opts: {
  title: string;
  details: string;
  startsAt: string;
  endsAt: string;
  location?: string;
}) {
  const fmt = (iso: string) => new Date(iso).toISOString().replace(/[-:]|\.\d{3}/g, "");
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: opts.title,
    details: opts.details,
    dates: `${fmt(opts.startsAt)}/${fmt(opts.endsAt)}`,
  });
  if (opts.location) params.set("location", opts.location);
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

/**
 * Finik payment integration point.
 * MVP: no API keys connected — the payment is simulated locally and the
 * booking is marked as paid in demo mode. Production: create a Finik
 * invoice in a server function and confirm it from a signed webhook at
 * /api/public/hooks/finik.
 */
export const FINIK_DEMO = true;
