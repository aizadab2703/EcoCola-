import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "mentor" | "client";

export function useSession() {
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["session"],
    queryFn: async (): Promise<Session | null> => {
      const { data } = await supabase.auth.getSession();
      return data.session;
    },
    staleTime: 30_000,
  });

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") {
        void qc.invalidateQueries({ queryKey: ["session"] });
        void qc.invalidateQueries({ queryKey: ["roles"] });
      }
    });
    return () => sub.subscription.unsubscribe();
  }, [qc]);

  return { session: data ?? null, user: data?.user ?? null, isLoading };
}

export function useRoles() {
  const { user } = useSession();
  const { data } = useQuery({
    queryKey: ["roles", user?.id ?? null],
    enabled: !!user,
    queryFn: async (): Promise<AppRole[]> => {
      const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", user!.id);
      if (error) throw error;
      return (data ?? []).map((r) => r.role as AppRole);
    },
  });
  const roles = data ?? [];
  return {
    roles,
    isAdmin: roles.includes("admin"),
    isMentor: roles.includes("mentor"),
  };
}

export async function signOutEverywhere(qc: ReturnType<typeof useQueryClient>) {
  await qc.cancelQueries();
  qc.clear();
  await supabase.auth.signOut();
}
