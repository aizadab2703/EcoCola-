import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { getVisitorCountry } from "@/lib/geo.functions";


export type Locale = "ru" | "en";

type Dict = Record<string, { ru: string; en: string }>;

export const dict: Dict = {
  "nav.mentors": { ru: "Эксперты", en: "Experts" },
  "nav.how": { ru: "Как это работает", en: "How it works" },
  "nav.become": { ru: "Стать экспертом", en: "Become an expert" },
  "nav.offer": { ru: "Оферта", en: "Terms" },
  "nav.dashboard": { ru: "Кабинет", en: "Dashboard" },
  "nav.mentorCabinet": { ru: "Кабинет эксперта", en: "Expert dashboard" },
  "nav.admin": { ru: "Админка", en: "Admin" },
  "nav.signin": { ru: "Войти", en: "Sign in" },
  "nav.signout": { ru: "Выйти", en: "Sign out" },
  "nav.themeDark": { ru: "Тёмная тема", en: "Dark theme" },
  "nav.themeLight": { ru: "Светлая тема", en: "Light theme" },

  "hero.staticStart": { ru: "Растите быстрее с экспертом по", en: "Grow faster with an expert in" },
  "hero.sub": {
    ru: "VirtualAccelerate MentorHub — пространство, где предприниматели находят опыт и поддержку для следующего шага в бизнесе.\n\nВыбирайте эксперта под свой запрос, оставляйте заявку и получайте персональную экспертную сессию с практиком из вашего региона.",
    en: "VirtualAccelerate MentorHub is a space where entrepreneurs find experience and support for their next business step.\n\nChoose an expert for your request, submit an application, and receive a personal expert session with a practitioner from your region.",
  },
  "hero.cta": { ru: "Найти эксперта", en: "Find an expert" },
  "hero.cta2": { ru: "Стать экспертом", en: "Become an expert" },

  "stats.mentors": { ru: "экспертов в сети", en: "experts in the network" },
  "stats.sessions": { ru: "проведённых сессий", en: "sessions delivered" },
  "stats.rating": { ru: "средний рейтинг", en: "average rating" },
  "stats.countries": { ru: "страны региона", en: "countries in the region" },

  "how.title": { ru: "Три шага до сессии", en: "Three steps to your session" },
  "how.1.t": { ru: "Выберите эксперта", en: "Pick an expert" },
  "how.1.d": {
    ru: "Фильтруйте по направлению, языку, стране и цене за час.",
    en: "Filter by track, language, country and hourly price.",
  },
  "how.2.t": { ru: "Забронируйте слот", en: "Book a slot" },
  "how.2.d": {
    ru: "Свободное время эксперта в его часовом поясе, сессия 60 минут.",
    en: "Expert's free time in their timezone, 60-minute session.",
  },
  "how.3.t": { ru: "Мы организуем вам онлайн-встречу", en: "We'll set up your online meeting" },
  "how.3.d": {
    ru: "Команда свяжется с вами, поможет согласовать время, формат онлайн-встречи и оплату.",
    en: "Our team will contact you to arrange a time, the online meeting format, and payment.",
  },

  "cats.title": { ru: "Направления", en: "Tracks" },
  "cats.sub": {
    ru: "Восемь практических направлений — от привлечения инвестиций до LLM в проде.",
    en: "Eight practical tracks — from fundraising to LLM in production.",
  },

  "featured.title": { ru: "Эксперты недели", en: "Experts of the week" },
  "featured.all": { ru: "Весь каталог", en: "Full catalog" },

  "catalog.title": { ru: "Каталог экспертов", en: "Expert catalog" },
  "catalog.search": { ru: "Поиск по имени или экспертизе", en: "Search by name or expertise" },
  "catalog.category": { ru: "Направление", en: "Track" },
  "catalog.country": { ru: "Страна", en: "Country" },
  "catalog.language": { ru: "Язык", en: "Language" },
  "catalog.all": { ru: "Все", en: "All" },
  "catalog.empty": { ru: "Никого не нашлось. Смягчите фильтры.", en: "Nothing found. Loosen the filters." },
  "catalog.found": { ru: "найдено", en: "found" },
  "catalog.reset": { ru: "Сбросить", en: "Reset" },
  "catalog.openProfile": { ru: "Открыть профиль →", en: "Open profile →" },
  "catalog.emptyBio": { ru: "Нет описания", en: "No description" },
  "catalog.activeFilter": { ru: "Направление", en: "Track" },
  "catalog.clearFilter": { ru: "Сбросить направление", en: "Clear track" },

  "mentor.book": { ru: "Забронировать сессию", en: "Book a session" },
  "mentor.perHour": { ru: "за час", en: "per hour" },
  "mentor.sessions": { ru: "сессий", en: "sessions" },
  "mentor.reviews": { ru: "отзывов", en: "reviews" },
  "mentor.about": { ru: "Об эксперте", en: "About the expert" },
  "mentor.expertise": { ru: "Экспертиза", en: "Expertise" },
  "mentor.languages": { ru: "Языки", en: "Languages" },
  "mentor.slots": { ru: "Свободные слоты", en: "Available slots" },
  "mentor.noSlots": { ru: "Пока нет свободных слотов", en: "No free slots yet" },
  "mentor.reviewsTitle": { ru: "Отзывы", en: "Reviews" },
  "mentor.topic": { ru: "Тема сессии", en: "Session topic" },
  "mentor.topic30": { ru: "Тема сессии (30 минут)", en: "Session topic (30 minutes)" },
  "mentor.topicPh30": { ru: "Что хотите разобрать за 30 минут?", en: "What do you want to work through in 30 minutes?" },
  "mentor.topic60": { ru: "Тема сессии (60 минут)", en: "Session topic (60 minutes)" },
  "mentor.topicPh60": { ru: "Что хотите разобрать за 60 минут?", en: "What do you want to work through in 60 minutes?" },
  "mentor.confirm": { ru: "Перейти к оплате", en: "Continue to payment" },
  "mentor.needAuth": { ru: "Войдите, чтобы забронировать", en: "Sign in to book" },
  "mentor.notFound": { ru: "Эксперт не найден", en: "Expert not found" },

  "booking.created": { ru: "Бронь создана", en: "Booking created" },
  "booking.title": { ru: "Бронирование", en: "Booking" },
  "booking.status": { ru: "Статус", en: "Status" },
  "booking.amount": { ru: "Сумма", en: "Amount" },
  "booking.when": { ru: "Когда", en: "When" },
  "booking.pay": { ru: "Оплатить через Finik (демо)", en: "Pay with Finik (demo)" },
  "booking.demoNote": {
    ru: "Демо-режим: реальные ключи Finik ещё не подключены, платёж имитируется на стороне приложения и не списывает деньги.",
    en: "Demo mode: real Finik keys are not connected yet, the payment is simulated in-app and no money is charged.",
  },
  "booking.paid": { ru: "Оплачено (демо)", en: "Paid (demo)" },
  "booking.meet": { ru: "Ссылка на встречу", en: "Meeting link" },
  "booking.meetPending": {
    ru: "Google Meet подключается после оплаты. В MVP выдаётся демо-ссылка.",
    en: "Google Meet is attached after payment. The MVP issues a demo link.",
  },
  "booking.calendar": { ru: "Добавить в Google Calendar", en: "Add to Google Calendar" },
  "booking.cancel": { ru: "Отменить", en: "Cancel" },
  "booking.cancelled": { ru: "Бронь отменена", en: "Booking cancelled" },

  "status.pending_payment": { ru: "Ожидает оплаты", en: "Awaiting payment" },
  "status.confirmed": { ru: "Подтверждена", en: "Confirmed" },
  "status.completed": { ru: "Завершена", en: "Completed" },
  "status.cancelled": { ru: "Отменена", en: "Cancelled" },

  "auth.title": { ru: "Вход в MentorHub", en: "Sign in to MentorHub" },
  "auth.sub": { ru: "Кабинет клиента, эксперта и админа", en: "Client, expert and admin dashboards" },
  "auth.email": { ru: "Email", en: "Email" },
  "auth.password": { ru: "Пароль", en: "Password" },
  "auth.name": { ru: "Имя", en: "Name" },
  "auth.signin": { ru: "Войти", en: "Sign in" },
  "auth.signup": { ru: "Создать аккаунт", en: "Create account" },
  "auth.google": { ru: "Продолжить с Google", en: "Continue with Google" },
  "auth.toSignup": { ru: "Нет аккаунта? Зарегистрируйтесь", en: "No account? Sign up" },
  "auth.toSignin": { ru: "Уже есть аккаунт? Войти", en: "Already have an account? Sign in" },
  "auth.checkEmail": {
    ru: "Проверьте почту и подтвердите адрес, чтобы войти.",
    en: "Check your email and confirm the address to sign in.",
  },

  "dash.title": { ru: "Мои сессии", en: "My sessions" },
  "dash.empty": { ru: "Пока нет бронирований", en: "No bookings yet" },
  "dash.find": { ru: "Найти эксперта", en: "Find an expert" },
  "dash.upcoming": { ru: "Предстоящие", en: "Upcoming" },
  "dash.past": { ru: "Прошедшие", en: "Past" },

  "mc.title": { ru: "Кабинет эксперта", en: "Expert dashboard" },
  "mc.noProfile": {
    ru: "К вашему аккаунту не привязан профиль эксперта. Попросите администратора отправить приглашение.",
    en: "No expert profile is linked to your account. Ask an admin to send an invitation.",
  },
  "mc.profile": { ru: "Профиль", en: "Profile" },
  "mc.schedule": { ru: "Расписание", en: "Schedule" },
  "mc.requests": { ru: "Заявки", en: "Requests" },
  "mc.addSlot": { ru: "Добавить слот", en: "Add slot" },
  "mc.price": { ru: "Цена за час", en: "Hourly price" },
  "mc.published": { ru: "Опубликован в каталоге", en: "Published in catalog" },
  "mc.save": { ru: "Сохранить", en: "Save" },
  "mc.saved": { ru: "Сохранено", en: "Saved" },
  "mc.markDone": { ru: "Отметить завершённой", en: "Mark completed" },

  "admin.title": { ru: "Админ-панель", en: "Admin panel" },
  "admin.mentors": { ru: "Эксперты", en: "Experts" },
  "admin.bookings": { ru: "Бронирования", en: "Bookings" },
  "admin.invites": { ru: "Приглашения", en: "Invitations" },
  "admin.invite": { ru: "Пригласить эксперта", en: "Invite an expert" },
  "admin.inviteSent": { ru: "Приглашение создано и отправлено", en: "Invitation created and sent" },
  "admin.inviteResent": { ru: "Приглашение отправлено повторно", en: "Invitation resent" },
  "admin.resendInvite": { ru: "Отправить приглашение повторно", en: "Resend invitation" },
  "admin.emailExists": { ru: "Этот email уже используется другим экспертом", en: "This email is already used by another expert" },
  "admin.copyLink": { ru: "Скопировать ссылку", en: "Copy link" },
  "admin.copied": { ru: "Ссылка скопирована", en: "Link copied" },
  "admin.revoke": { ru: "Отозвать", en: "Revoke" },
  "admin.publish": { ru: "Публиковать", en: "Publish" },
  "admin.unpublish": { ru: "Снять", en: "Unpublish" },
  "admin.revenue": { ru: "Оборот (демо)", en: "Revenue (demo)" },
  "admin.noAccess": { ru: "Доступ только для администраторов", en: "Administrators only" },
  "admin.applications": { ru: "Заявки «Стать экспертом»", en: "Expert applications" },
  "admin.appEmpty": { ru: "Пока нет заявок", en: "No applications yet" },
  "admin.appToMentor": { ru: "Создать эксперта из заявки", en: "Create expert from application" },
  "admin.created": { ru: "Дата заявки", en: "Submitted" },

  "admin.approve": { ru: "Одобрить", en: "Approve" },
  "admin.reject": { ru: "Отклонить", en: "Reject" },
  "admin.addMentor": { ru: "Добавить эксперта", en: "Add expert" },
  "admin.newMentor": { ru: "Новый эксперт", en: "New expert" },
  "admin.delete": { ru: "Удалить", en: "Delete" },
  "admin.saved": { ru: "Сохранено", en: "Saved" },
  "admin.price": { ru: "Цена за час", en: "Price per hour" },
  "admin.mentorSearch": {
    ru: "Поиск по имени, должности, email, стране или направлениям",
    en: "Search by name, job title, email, country or sectors",
  },
  "admin.mentorEmpty": { ru: "Эксперты по запросу не найдены", en: "No experts match your search" },
  "admin.deleteMentorConfirm": {
    ru: "Удалить эксперта {name}? Профиль, фото и связанные данные будут удалены без возможности восстановления.",
    en: "Delete expert {name}? Profile, photo and related data will be permanently removed.",
  },
  "admin.mentorDeleted": { ru: "Эксперт удалён", en: "Expert deleted" },
  "admin.editMentor": { ru: "Редактировать эксперта", en: "Edit expert" },
  "admin.save": { ru: "Сохранить", en: "Save" },
  "admin.cancel": { ru: "Отмена", en: "Cancel" },
  "admin.edit": { ru: "Редактировать", en: "Edit" },
  "admin.pause": { ru: "Приостановить", en: "Pause" },
  "admin.f.photo": { ru: "Фото эксперта", en: "Expert photo" },
  "admin.f.photoUpload": { ru: "Загрузить фото", en: "Upload photo" },
  "admin.f.photoUploading": { ru: "Загрузка…", en: "Uploading…" },
  "admin.f.photoUrlOptional": { ru: "Или ссылка на фото (необязательно)", en: "Or a photo link (optional)" },
  "admin.f.photoDone": { ru: "Фото загружено", en: "Photo uploaded" },
  "admin.f.photoType": { ru: "Нужен файл изображения", en: "Please choose an image file" },
  "admin.f.photoSize": { ru: "Файл больше 5 МБ", en: "File is larger than 5 MB" },
  "admin.f.jobTitle": { ru: "Должность", en: "Job title" },
  "admin.f.jobTitlePh": { ru: "Например: Head of Growth, Kaspi", en: "e.g. Head of Growth, Kaspi" },
  "admin.f.sectors": { ru: "Направления", en: "Sectors" },
  "admin.f.languages": { ru: "Языки", en: "Languages" },
  "admin.f.sectorCustom": { ru: "Своё направление", en: "Custom sector" },
  "admin.f.name": { ru: "Имя и фамилия", en: "Full name" },
  "admin.f.country": { ru: "Страна", en: "Country" },
  "admin.f.shortBio": { ru: "Краткое описание (2–3 предложения)", en: "Short summary (2-3 sentences)" },
  "admin.f.shortBioPh": {
    ru: "Коротко о том, чем эксперт может помочь",
    en: "Briefly: how this expert can help",
  },
  "admin.f.bio": { ru: "Биография", en: "Bio" },
  "admin.f.price30": { ru: "Цена за 30 минут", en: "Price for 30 min" },
  "admin.f.price60": { ru: "Цена за 60 минут", en: "Price for 60 min" },
  "admin.f.currency": { ru: "Валюта цены", en: "Price currency" },
  "admin.f.fxLive": { ru: "Курс НБКР", en: "NBKR rate" },
  "admin.f.fxFallback": { ru: "Курс недоступен, показан сохранённый курс", en: "Live rate unavailable, cached rate shown" },
  "admin.f.fxLoading": { ru: "Загрузка курса…", en: "Loading rates…" },
  "admin.f.status": { ru: "Статус", en: "Status" },
  "admin.f.invite": {
    ru: "Email эксперта (сохраняется, используется для приглашения и Google Calendar)",
    en: "Expert email (saved, used for the invitation and Google Calendar)",
  },

  "status.pending": { ru: "На модерации", en: "Pending" },
  "status.active": { ru: "Активен", en: "Active" },
  "status.paused": { ru: "Приостановлен", en: "Paused" },

  "cur.label": { ru: "Валюта отображения", en: "Display currency" },
  "cur.note": { ru: "Цены пересчитаны по курсу НБКР", en: "Prices converted at NBKR rates" },

  "book.duration": { ru: "Длительность сессии", en: "Session length" },
  "book.min30": { ru: "30 минут", en: "30 minutes" },
  "book.min60": { ru: "60 минут", en: "60 minutes" },
  "book.requestTitle": { ru: "Заявка на сессию", en: "Session request" },
  "book.name": { ru: "Ваше имя", en: "Your name" },
  "book.phone": { ru: "Телефон / WhatsApp", en: "Phone / WhatsApp" },
  "book.method": { ru: "Удобный способ связи", en: "Preferred contact method" },
  "book.method.whatsapp": { ru: "WhatsApp", en: "WhatsApp" },
  "book.method.telegram": { ru: "Telegram", en: "Telegram" },
  "book.method.call": { ru: "Звонок", en: "Phone call" },
  "book.method.email": { ru: "Email", en: "Email" },
  "book.preferred": { ru: "Удобное время", en: "Preferred time" },
  "book.preferredPh": { ru: "Например: будни после 18:00", en: "e.g. weekdays after 6pm" },
  "book.note": { ru: "Комментарий", en: "Comment" },
  "book.notePh": {
    ru: "Будет полезно, если дадите больше информации и контекста о бизнесе и о себе",
    en: "It helps if you share more information and context about your business and yourself",
  },
  "book.send": { ru: "Отправить заявку", en: "Send request" },
  "book.sent": { ru: "Заявка отправлена — команда свяжется с вами для согласования времени.", en: "Request sent — our team will contact you to agree on a time." },
  "book.contactNote": { ru: "Оплата пока не подключена: после заявки команда свяжется с вами и согласует время и оплату.", en: "Payments are not enabled yet: after your request our team will contact you to agree on time and payment." },
  "book.required": { ru: "Заполните имя и телефон", en: "Please fill in name and phone" },
  "book.contacts": { ru: "Контакты", en: "Contacts" },
  "book.reqStatus": { ru: "Статус заявки", en: "Request status" },
  "admin.b.client": { ru: "Клиент", en: "Client" },
  "admin.b.mentor": { ru: "Эксперт", en: "Expert" },
  "admin.b.created": { ru: "Создана", en: "Created" },
  "admin.b.session": { ru: "Дата сессии", en: "Session date" },
  "admin.b.details": { ru: "Детали заявки", en: "Request details" },
  "admin.b.open": { ru: "Открыть", en: "Open" },
  "admin.b.copyPhone": { ru: "Скопировать телефон", en: "Copy phone" },
  "admin.b.copyEmail": { ru: "Скопировать email", en: "Copy email" },
  "admin.b.copied": { ru: "Скопировано", en: "Copied" },
  "admin.b.empty": { ru: "Пока нет заявок", en: "No requests yet" },
  "admin.b.close": { ru: "Закрыть", en: "Close" },
  "reqstatus.new": { ru: "Новая заявка", en: "New request" },
  "reqstatus.contacted": { ru: "Согласование", en: "In discussion" },
  "reqstatus.scheduled": { ru: "Время согласовано", en: "Scheduled" },
  "reqstatus.confirmed": { ru: "Подтверждена", en: "Confirmed" },
  "reqstatus.completed": { ru: "Завершена", en: "Completed" },
  "reqstatus.cancelled": { ru: "Отменена", en: "Cancelled" },
  "reqstatus.declined": { ru: "Отклонена", en: "Declined" },
  "admin.b.planning": { ru: "Планирование сессии", en: "Session planning" },
  "admin.b.planNotice": {
    ru: "Время назначается вручную: доступность календаря эксперта нужно подтвердить отдельно перед отправкой приглашения.",
    en: "Time is set manually: confirm the expert's calendar availability separately before sending the invite.",
  },
  "admin.b.date": { ru: "Дата", en: "Date" },
  "admin.b.time": { ru: "Время", en: "Time" },
  "admin.b.tz": { ru: "Часовой пояс", en: "Time zone" },
  "admin.b.gcal": { ru: "Google Calendar invite", en: "Google Calendar invite" },
  "admin.b.mentorEmail": { ru: "Email эксперта", en: "Expert email" },
  "admin.b.noMentorEmail": {
    ru: "Email эксперта не указан в анкете — он не будет добавлен в приглашение. Добавьте email эксперта, чтобы он получил событие в Google Calendar.",
    en: "The expert has no email in their application — they won't be added to the invite. Add the expert's email so they receive the Google Calendar event.",
  },

  "admin.b.planRequired": { ru: "Укажите дату и время", en: "Pick a date and time" },
  "admin.b.futureIntegration": {
    ru: "Далее: эксперт подключит свой Google Calendar, свободные слоты будут проверяться автоматически, а событие создаваться в календарях эксперта и клиента.",
    en: "Next: experts connect their own Google Calendar, free slots are checked automatically, and the event is created in both calendars.",
  },

  "footer.tagline": {
    ru: "VirtualAccelerate MentorHub — доступ к опыту практикующих предпринимателей и экспертов для роста вашего бизнеса.",
    en: "VirtualAccelerate MentorHub — access to the experience of practicing entrepreneurs and experts to grow your business.",
  },
  "footer.product": { ru: "Продукт", en: "Product" },
  "footer.legal": { ru: "Документы", en: "Legal" },
  "footer.rights": { ru: "Все права защищены.", en: "All rights reserved." },

  "offer.title": { ru: "Публичная оферта", en: "Public offer" },
  "loading": { ru: "Загрузка…", en: "Loading…" },
  "error": { ru: "Что-то пошло не так", en: "Something went wrong" },

  "catalog.sub": {
    ru: "Фильтруйте по направлению, стране, языку и бюджету — и бронируйте слот в пару кликов.",
    en: "Filter by track, country, language and budget — then book a slot in a couple of clicks.",
  },
  "catalog.searchPlaceholder": { ru: "Например: юнит-экономика, Series A, LLM", en: "e.g. unit economics, Series A, LLM" },
  "catalog.allCats": { ru: "Все направления", en: "All tracks" },
  "catalog.any": { ru: "Любой", en: "Any" },
  "catalog.maxPrice": { ru: "До", en: "Up to" },

  "admin.deleteInvite": { ru: "Удалить приглашение", en: "Delete invitation" },
  "admin.deleteInviteConfirm": {
    ru: "Удалить приглашение для {email}? Профиль эксперта останется без изменений.",
    en: "Delete the invitation for {email}? The expert profile stays unchanged.",
  },
  "admin.inviteDeleted": { ru: "Приглашение удалено", en: "Invitation deleted" },

  "admin.invitedMentors": { ru: "Приглашённые эксперты", en: "Invited experts" },
  "admin.noInvitedMentors": {
    ru: "Пока нет экспертов с указанным email.",
    en: "No experts with an email yet.",
  },
  "admin.inviteNotSent": { ru: "не отправлено", en: "not sent" },

  "admin.f.enTitle": { ru: "Английская версия", en: "English version" },
  "admin.f.enHint": {
    ru: "Заполняется автоматически при сохранении. Можно отредактировать вручную — ручной текст сохраняется.",
    en: "Filled automatically on save. You can edit it manually — manual text is kept.",
  },
  "admin.f.translate": { ru: "Перевести на EN", en: "Translate to EN" },
  "admin.f.trBusy": { ru: "Переводим…", en: "Translating…" },
  "admin.f.trDone": { ru: "Перевод готов", en: "Translation ready" },
  "admin.f.trFailed": { ru: "Не удалось перевести", en: "Translation failed" },
  "admin.translateAll": { ru: "Перевести анкеты на EN", en: "Translate profiles to EN" },
  "admin.translateAllDone": { ru: "Переводы обновлены", en: "Translations updated" },

  "become.title": { ru: "Станьте экспертом MentorHub", en: "Become a MentorHub expert" },
  "become.sub": {
    ru: "Мы работаем по модели приглашений: расскажите о себе, и команда VirtualAccelerate свяжется с вами.",
    en: "We onboard by invitation: tell us about yourself and the VirtualAccelerate team will reach out.",
  },
  "become.name": { ru: "Имя и фамилия", en: "Full name" },
  "become.email": { ru: "Email", en: "Email" },
  "become.about": { ru: "Экспертиза и опыт", en: "Expertise and experience" },
  "become.phone": { ru: "Телефон / WhatsApp", en: "Phone / WhatsApp" },

  "become.send": { ru: "Отправить заявку", en: "Send application" },
  "become.sent": { ru: "Заявка отправлена — мы напишем на указанный email.", en: "Application sent — we will email you." },
  "become.b1t": { ru: "Ваша ставка — ваши правила", en: "Your rate, your rules" },
  "become.b1d": {
    ru: "Вы задаёте цену часа и открываете только те слоты, которые вам удобны.",
    en: "You set the hourly price and open only the slots that suit you.",
  },
  "become.b2t": { ru: "Поток клиентов", en: "Client flow" },
  "become.b2d": {
    ru: "Каталог, SEO и сообщество VirtualAccelerate приводят предпринимателей региона.",
    en: "The catalog, SEO and the VirtualAccelerate community bring in regional founders.",
  },
  "become.b3t": { ru: "Оплата и созвон — подключим вместе", en: "Payments and calls — we set it up together" },
  "become.b3d": {
    ru: "Оплата через Finik, встречи в Google Meet — сейчас команда помогает согласовать каждую сессию вручную, автоматизация в разработке.",
    en: "Finik payments and Google Meet calls — for now the team helps coordinate every session manually, automation is in development.",
  },
};


type Ctx = { locale: Locale; setLocale: (l: Locale) => void; t: (k: string) => string };

const I18nContext = createContext<Ctx>({ locale: "ru", setLocale: () => {}, t: (k) => k });

const RU_COUNTRIES = new Set(["KG", "KZ", "UZ", "TJ", "RU", "BY", "TM", "AM", "AZ", "MD", "GE"]);

function localeFromBrowser(): Locale {
  const langs = [navigator.language, ...(navigator.languages ?? [])];
  if (langs.some((l) => l?.toLowerCase().startsWith("ru"))) return "ru";
  try {
    for (const l of langs) {
      if (!l) continue;
      const region = new Intl.Locale(l).maximize().region;
      if (region && RU_COUNTRIES.has(region)) return "ru";
    }
  } catch {
    /* ignore */
  }
  return "en";
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("ru");

  useEffect(() => {
    const saved = window.localStorage.getItem("va-locale");
    if (saved === "ru" || saved === "en") {
      setLocaleState(saved);
      document.documentElement.lang = saved;
      return;
    }
    // No manual choice yet: detect by visitor country, fall back to browser language.
    let alive = true;
    void (async () => {
      let next: Locale;
      try {
        const { country } = await getVisitorCountry();
        next = country ? (RU_COUNTRIES.has(country) ? "ru" : "en") : localeFromBrowser();
      } catch {
        next = localeFromBrowser();
      }
      if (!alive) return;
      setLocaleState(next);
      document.documentElement.lang = next;
    })();
    return () => {
      alive = false;
    };
  }, []);


  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    window.localStorage.setItem("va-locale", l);
    document.documentElement.lang = l;
  }, []);

  const t = useCallback((k: string) => dict[k]?.[locale] ?? k, [locale]);

  const value = useMemo(() => ({ locale, setLocale, t }), [locale, setLocale, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  return useContext(I18nContext);
}
