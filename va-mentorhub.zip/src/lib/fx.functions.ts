import { createServerFn } from "@tanstack/react-start";

export const FX_CURRENCIES = ["KGS", "USD", "KZT", "UZS", "PKR"] as const;

/** NBKR does not quote PKR, so it is derived from USD with a periodically reviewed rate. */
const PKR_PER_USD = 283;
export type FxCurrency = (typeof FX_CURRENCIES)[number];

/** KGS per 1 unit of currency. */
export type FxRates = Record<FxCurrency, number>;

export type FxResult = {
  rates: FxRates;
  /** Rate date as shown by the source (DD.MM.YYYY) or ISO date for the fallback. */
  date: string;
  source: string;
  live: boolean;
};

/** Transparent fallback used when the NBKR feed cannot be reached. */
const FALLBACK: FxResult = {
  rates: { KGS: 1, USD: 87.45, KZT: 0.1911, UZS: 0.00741, PKR: 87.45 / PKR_PER_USD },
  date: "2026-09-05",
  source: "NBKR (cached snapshot)",
  live: false,
};

function parseRates(xml: string, want: string[]) {
  const out: Record<string, number> = {};
  const re = /<Currency ISOCode="([A-Z]+)">([\s\S]*?)<\/Currency>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const code = m[1]!;
    if (!want.includes(code)) continue;
    const body = m[2]!;
    const nominal = Number(body.match(/<Nominal>([\d.,]+)<\/Nominal>/)?.[1]?.replace(",", ".") ?? "1");
    const value = Number(body.match(/<Value>([\d.,]+)<\/Value>/)?.[1]?.replace(",", "."));
    if (Number.isFinite(value) && nominal > 0) out[code] = value / nominal;
  }
  return out;
}

function parseDate(xml: string) {
  return xml.match(/Date="([^"]+)"/)?.[1] ?? "";
}

export const getFxRates = createServerFn({ method: "GET" }).handler(async (): Promise<FxResult> => {
  try {
    const [daily, weekly] = await Promise.all([
      fetch("https://www.nbkr.kg/XML/daily.xml").then((r) => (r.ok ? r.text() : "")),
      fetch("https://www.nbkr.kg/XML/weekly.xml").then((r) => (r.ok ? r.text() : "")),
    ]);
    const merged = { ...parseRates(weekly, ["UZS"]), ...parseRates(daily, ["USD", "KZT"]) };
    const usd = merged["USD"];
    const kzt = merged["KZT"];
    const uzs = merged["UZS"];
    if (!usd || !kzt || !uzs) return FALLBACK;
    return {
      rates: { KGS: 1, USD: usd, KZT: kzt, UZS: uzs, PKR: usd / PKR_PER_USD },
      date: parseDate(daily) || parseDate(weekly),
      source: "НБКР / NBKR",
      live: true,
    };
  } catch {
    return FALLBACK;
  }
});

export function convert(amount: number, from: FxCurrency, to: FxCurrency, rates: FxRates) {
  if (!amount) return 0;
  const inKgs = amount * (rates[from] || 1);
  return inKgs / (rates[to] || 1);
}

/** Sensible rounding: whole units for strong currencies, tidy steps for weak ones. */
export function roundMoney(value: number, currency: FxCurrency) {
  if (currency === "UZS") return Math.round(value / 1000) * 1000;
  if (currency === "KZT") return Math.round(value / 100) * 100;
  if (currency === "PKR") return Math.round(value / 100) * 100;
  if (currency === "KGS") return Math.round(value / 10) * 10;
  return Math.round(value);
}
