import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  FX_CURRENCIES,
  convert,
  getFxRates,
  roundMoney,
  type FxCurrency,
  type FxResult,
} from "@/lib/fx.functions";
import { getVisitorCountry } from "@/lib/geo.functions";
import type { Locale } from "@/lib/i18n";

const STORAGE_KEY = "va-currency";

/** Country → local display currency; everything else falls back to USD. */
export function currencyForCountry(country: string | null | undefined): FxCurrency {
  switch ((country ?? "").toUpperCase()) {
    case "KG":
      return "KGS";
    case "KZ":
      return "KZT";
    case "UZ":
      return "UZS";
    case "PK":
      return "PKR";
    default:
      return "USD";
  }
}

type Ctx = {
  currency: FxCurrency;
  setCurrency: (c: FxCurrency | null) => void;
  manual: boolean;
  fx: FxResult | undefined;
  /** Convert an amount stored in the mentor's base currency into the visitor's currency. */
  display: (amount: number, base: string, locale: Locale) => string;
};

const CurrencyContext = createContext<Ctx>({
  currency: "USD",
  setCurrency: () => {},
  manual: false,
  fx: undefined,
  display: (a) => String(a),
});

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [manualCurrency, setManualCurrency] = useState<FxCurrency | null>(null);
  const [detected, setDetected] = useState<FxCurrency>("USD");

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved && (FX_CURRENCIES as readonly string[]).includes(saved)) {
      setManualCurrency(saved as FxCurrency);
    }
  }, []);

  // Reliable-ish detection: server-side request country first, browser locale as backup.
  useEffect(() => {
    let alive = true;
    void (async () => {
      let country: string | null = null;
      try {
        country = (await getVisitorCountry()).country;
      } catch {
        country = null;
      }
      if (!country) {
        try {
          country = new Intl.Locale(navigator.language).maximize().region ?? null;
        } catch {
          country = null;
        }
      }
      if (alive) setDetected(currencyForCountry(country));
    })();
    return () => {
      alive = false;
    };
  }, []);

  const fxQ = useQuery({ queryKey: ["fx-rates"], queryFn: () => getFxRates(), staleTime: 60 * 60 * 1000 });

  const currency = manualCurrency ?? detected;

  const value = useMemo<Ctx>(() => {
    const fx = fxQ.data;
    return {
      currency,
      manual: manualCurrency !== null,
      fx,
      setCurrency: (c) => {
        setManualCurrency(c);
        if (c) window.localStorage.setItem(STORAGE_KEY, c);
        else window.localStorage.removeItem(STORAGE_KEY);
      },
      display: (amount, base, locale) => {
        const from = ((FX_CURRENCIES as readonly string[]).includes(base) ? base : "KGS") as FxCurrency;
        const target = currency;
        const converted =
          fx && from !== target ? roundMoney(convert(amount, from, target, fx.rates), target) : amount;
        return new Intl.NumberFormat(locale === "ru" ? "ru-RU" : "en-US", {
          style: "currency",
          currency: fx || from === target ? target : from,
          maximumFractionDigits: 0,
        }).format(converted);
      },
    };
  }, [currency, manualCurrency, fxQ.data]);

  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrency() {
  return useContext(CurrencyContext);
}
