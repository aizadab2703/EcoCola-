import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";

/** Best-effort visitor country from edge/proxy headers. Null means "unknown". */
export const getVisitorCountry = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ country: string | null }> => {
    const candidates = ["cf-ipcountry", "x-vercel-ip-country", "x-country-code", "x-geo-country"];
    for (const h of candidates) {
      const value = getRequestHeader(h);
      if (value && value.length === 2 && value.toUpperCase() !== "XX") {
        return { country: value.toUpperCase() };
      }
    }
    return { country: null };
  },
);
