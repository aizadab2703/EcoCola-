/** Cyrillic (RU/KG) -> Latin transliteration for displaying names in English. */
const MAP: Record<string, string> = {
  а: "a", б: "b", в: "v", г: "g", ғ: "g", д: "d", е: "e", ё: "yo", ж: "zh", з: "z",
  и: "i", й: "y", к: "k", қ: "k", л: "l", м: "m", н: "n", ң: "ng", о: "o", ө: "o",
  п: "p", р: "r", с: "s", т: "t", у: "u", ү: "u", ұ: "u", ф: "f", х: "kh", һ: "h",
  ц: "ts", ч: "ch", ш: "sh", щ: "shch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya",
  і: "i", ї: "yi", є: "ye", ә: "a", ӂ: "zh",
};

export function hasCyrillic(value: string) {
  return /[\u0400-\u04FF]/.test(value);
}

function transliterateWord(word: string) {
  let out = "";
  for (const ch of word) {
    const lower = ch.toLowerCase();
    const mapped = MAP[lower];
    if (mapped === undefined) {
      out += ch;
      continue;
    }
    if (ch === lower) out += mapped;
    else out += mapped ? (mapped[0] as string).toUpperCase() + mapped.slice(1) : "";
  }
  return out;
}

/** Transliterates a person name; returns the input untouched if it is already Latin. */
export function transliterateName(value: string) {
  const trimmed = (value ?? "").trim();
  if (!trimmed || !hasCyrillic(trimmed)) return trimmed;
  return trimmed.split(/(\s+|-)/).map(transliterateWord).join("");
}
