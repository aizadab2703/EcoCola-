import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const input = z.object({
  job_title: z.string().max(200).default(""),
  short_bio: z.string().max(600).default(""),
  bio: z.string().max(4000).default(""),
  sectors: z.array(z.string().max(80)).max(20).default([]),
});

export type MentorTranslation = {
  job_title_en: string;
  short_bio_en: string;
  bio_en: string;
  sectors_en: string[];
};

/** Translates mentor profile copy RU -> EN. Names are never translated. */
export const translateMentorProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => input.parse(data))
  .handler(async ({ data }): Promise<MentorTranslation> => {
    const empty: MentorTranslation = {
      job_title_en: "",
      short_bio_en: "",
      bio_en: "",
      sectors_en: data.sectors,
    };
    if (!data.job_title && !data.short_bio && !data.bio && data.sectors.length === 0) return empty;

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("Translation service is not configured");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content:
              "You translate mentor marketplace profile copy from Russian into natural, professional English. " +
              "Keep the meaning, tone and length similar. Never translate personal names, brand or company names. " +
              "If a field is already English, return it unchanged. Return ONLY JSON matching the requested schema.",
          },
          {
            role: "user",
            content: JSON.stringify({
              job_title: data.job_title,
              short_bio: data.short_bio,
              bio: data.bio,
              sectors: data.sectors,
            }),
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "mentor_translation",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              properties: {
                job_title: { type: "string" },
                short_bio: { type: "string" },
                bio: { type: "string" },
                sectors: { type: "array", items: { type: "string" } },
              },
              required: ["job_title", "short_bio", "bio", "sectors"],
            },
          },
        },
      }),
    });

    if (!res.ok) {
      throw new Error(res.status === 429 ? "Translation rate limit, try again later" : "Translation failed");
    }

    const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: Record<string, unknown> = {};
    try {
      parsed = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      throw new Error("Translation failed");
    }

    const sectors = Array.isArray(parsed["sectors"]) ? (parsed["sectors"] as unknown[]).map(String) : [];
    return {
      job_title_en: String(parsed["job_title"] ?? ""),
      short_bio_en: String(parsed["short_bio"] ?? ""),
      bio_en: String(parsed["bio"] ?? ""),
      sectors_en: sectors.length === data.sectors.length ? sectors : data.sectors,
    };
  });
