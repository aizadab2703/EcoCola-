import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { Shell } from "@/components/site-chrome";
import { MentorCard } from "@/components/mentor-card";
import { Reveal } from "@/components/motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { COUNTRY_LABEL, LANG_LABEL, SECTORS, fetchCategories, fetchMentors } from "@/lib/mentorhub";
import { useCurrency } from "@/lib/currency";
import { FX_CURRENCIES, convert, roundMoney, type FxCurrency } from "@/lib/fx.functions";
import { NativeSelect } from "@/components/native-select";

/** Pick a readable slider step (1/2/5 × 10ⁿ) for roughly 20 notches. */
function niceStep(ceiling: number) {
  if (ceiling <= 0) return 1;
  const raw = ceiling / 20;
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / pow;
  const mult = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return mult * pow;
}

type CatalogSearch = { category?: string; q?: string };

export const Route = createFileRoute("/mentors/")({
  validateSearch: (s: Record<string, unknown>): CatalogSearch => ({
    ...(typeof s['category'] === "string" ? { category: s['category'] } : {}),
    ...(typeof s['q'] === "string" ? { q: s['q'] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Каталог экспертов — VirtualAccelerate MentorHub" },
      {
        name: "description",
        content: "Фильтруйте экспертов по направлению, стране, языку и цене. Бронируйте сессию 1:1 онлайн.",
      },
      { property: "og:title", content: "Каталог экспертов — MentorHub" },
      { property: "og:description", content: "Более 150 практиков Центральной Азии в одном каталоге." },
    ],
  }),
  component: Catalog,
});

function Catalog() {
  const { t, locale } = useI18n();
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/mentors/" });

  const mentors = useQuery({ queryKey: ["mentors"], queryFn: fetchMentors });
  const categories = useQuery({ queryKey: ["categories"], queryFn: fetchCategories });

  const [q, setQ] = useState(search.q ?? "");
  const [country, setCountry] = useState<string>("all");
  const [lang, setLang] = useState<string>("all");
  const [maxPrice, setMaxPrice] = useState<number>(0);

  const category = search.category ?? "all";
  const all = mentors.data ?? [];

  const { currency, fx } = useCurrency();

  /** Mentor price expressed in the visitor's display currency. */
  const toDisplay = useMemo(() => {
    return (amount: number, base: string) => {
      const from = ((FX_CURRENCIES as readonly string[]).includes(base) ? base : "KGS") as FxCurrency;
      if (!fx || from === currency) return amount;
      return roundMoney(convert(amount, from, currency, fx.rates), currency);
    };
  }, [currency, fx]);

  const money = (value: number) =>
    new Intl.NumberFormat(locale === "ru" ? "ru-RU" : "en-US", {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(value);

  const matchesCategory = (m: (typeof all)[number], slug: string) => {
    if (slug === "all") return true;
    if (m.category_slug === slug) return true;
    const sector = SECTORS.find((s) => s.value === slug);
    const tags = (m.expertise ?? []).map((e) => e.toLowerCase());
    return tags.some(
      (tagValue) =>
        tagValue === slug ||
        (sector ? tagValue === sector.ru.toLowerCase() || tagValue === sector.en.toLowerCase() : false),
    );
  };

  const activeSector = SECTORS.find((s) => s.value === category);
  const activeCategoryLabel =
    (categories.data ?? []).find((c) => c.slug === category) ??
    (activeSector ? { name_ru: activeSector.ru, name_en: activeSector.en } : null);

  const displayPrice = (m: (typeof all)[number]) =>
    toDisplay(m.price_60 || m.price_per_hour, m.currency);

  // Everything except the price filter — used both for the result list and
  // for the dynamic slider ceiling.
  const preFiltered = all.filter((m) => {
    if (!matchesCategory(m, category)) return false;
    if (country !== "all" && m.country !== country) return false;
    if (lang !== "all" && !m.languages.includes(lang)) return false;
    if (q.trim()) {
      const hay = `${m.full_name} ${m.headline_ru} ${m.headline_en} ${m.expertise.join(" ")}`.toLowerCase();
      if (!hay.includes(q.trim().toLowerCase())) return false;
    }
    return true;
  });

  const step = useMemo(() => {
    const top = preFiltered.length ? Math.max(...preFiltered.map(displayPrice)) : 0;
    return niceStep(top);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preFiltered.length, currency, fx, category, country, lang, q]);

  const priceCeiling = useMemo(() => {
    const top = preFiltered.length ? Math.max(...preFiltered.map(displayPrice)) : 0;
    return top > 0 ? Math.ceil(top / step) * step : 0;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preFiltered.length, currency, fx, category, country, lang, q, step]);

  // Re-scale the chosen limit when the currency changes; clamp when the
  // available result set (and therefore the ceiling) shrinks.
  const prevRef = useRef({ currency, priceCeiling });
  useEffect(() => {
    const prev = prevRef.current;
    prevRef.current = { currency, priceCeiling };
    if (!maxPrice) return;
    if (prev.currency !== currency) {
      const ratio = prev.priceCeiling > 0 ? maxPrice / prev.priceCeiling : 0;
      setMaxPrice(ratio > 0 ? Math.round((priceCeiling * ratio) / step) * step : 0);
    } else if (maxPrice > priceCeiling) {
      setMaxPrice(priceCeiling);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currency, priceCeiling, step]);

  const filtered = preFiltered.filter((m) => !maxPrice || displayPrice(m) <= maxPrice);

  const setCategory = (slug: string) =>
    navigate({
      search: (prev: CatalogSearch) => {
        const next: CatalogSearch = {};
        if (prev.q) next.q = prev.q;
        if (slug !== "all") next.category = slug;
        return next;
      },
    });

  return (
    <Shell>
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <Reveal>
            <h1 className="font-display text-3xl sm:text-4xl">{t("catalog.title")}</h1>
            <p className="mt-3 max-w-2xl text-muted-foreground">{t("catalog.sub")}</p>
          </Reveal>
          <div className="relative mt-7 max-w-xl">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("catalog.searchPlaceholder")}
              className="h-12 rounded-full pl-10"
            />
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="flex flex-wrap gap-2">
          <FilterChip active={category === "all"} onClick={() => setCategory("all")}>
            {t("catalog.allCats")}
          </FilterChip>
          {(categories.data ?? []).map((c) => (
            <FilterChip key={c.slug} active={category === c.slug} onClick={() => setCategory(c.slug)}>
              {locale === "ru" ? c.name_ru : c.name_en}
            </FilterChip>
          ))}
        </div>

        {category !== "all" && (
          <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl border border-primary/25 bg-primary/5 px-4 py-3 text-sm">
            <span className="text-muted-foreground">{t("catalog.activeFilter")}:</span>
            <span className="rounded-full bg-gradient-brand px-3 py-1 font-medium text-primary-foreground">
              {activeCategoryLabel
                ? locale === "ru"
                  ? activeCategoryLabel.name_ru
                  : activeCategoryLabel.name_en
                : category}
            </span>
            <Button variant="ghost" size="sm" onClick={() => setCategory("all")}>
              <X className="mr-1 h-3.5 w-3.5" />
              {t("catalog.clearFilter")}
            </Button>
          </div>
        )}

        <div className="mt-6 flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-4">
          <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
          <Select value={country} onChange={setCountry} label={t("catalog.country")}>
            <option value="all">{t("catalog.any")}</option>
            {Object.keys(COUNTRY_LABEL).map((code) => (
              <option key={code} value={code}>
                {COUNTRY_LABEL[code]![locale]}
              </option>
            ))}
          </Select>
          <Select value={lang} onChange={setLang} label={t("catalog.language")}>
            <option value="all">{t("catalog.any")}</option>
            {Object.keys(LANG_LABEL).map((code) => (
              <option key={code} value={code}>
                {LANG_LABEL[code]![locale]}
              </option>
            ))}
          </Select>
          <label className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">{t("catalog.maxPrice")}</span>
            <input
              type="range"
              min={0}
              max={priceCeiling}
              step={step}
              value={Math.min(maxPrice, priceCeiling)}
              disabled={priceCeiling <= 0}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="accent-[var(--primary)] disabled:opacity-50"
            />
            <span className="min-w-[6rem] font-medium">{maxPrice ? money(maxPrice) : t("catalog.any")}</span>
          </label>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto"
            onClick={() => {
              setCountry("all");
              setLang("all");
              setMaxPrice(0);
              setQ("");
              setCategory("all");
            }}
          >
            {t("catalog.reset")}
          </Button>
        </div>

        <p className="mt-6 text-sm text-muted-foreground">
          {t("catalog.found")}: <span className="font-semibold text-foreground">{filtered.length}</span>
        </p>

        {mentors.isLoading ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-56 animate-pulse rounded-2xl bg-secondary" />
            ))}
          </div>
        ) : filtered.length ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((m, i) => (
              <Reveal key={m.id} delay={Math.min(i, 6) * 60}>
                <MentorCard mentor={m} />
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="mt-10 rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">
            {t("catalog.empty")}
          </div>
        )}
      </div>
    </Shell>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200 ${
        active
          ? "border-transparent bg-gradient-brand text-primary-foreground shadow-glow"
          : "border-border bg-card text-muted-foreground hover:-translate-y-0.5 hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function Select({
  value,
  onChange,
  label,
  children,
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <NativeSelect value={value} onChange={(e) => onChange(e.target.value)} wrapperClassName="w-auto min-w-[9rem]">
        {children}
      </NativeSelect>
    </label>
  );
}
