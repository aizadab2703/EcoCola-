import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Coins, Rocket, Upload, Users } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Shell } from "@/components/site-chrome";
import { Reveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/lib/i18n";
import { PhoneInput } from "@/components/phone-input";

import { supabase } from "@/integrations/supabase/client";
import { COUNTRY_LABEL, SECTORS } from "@/lib/mentorhub";
import { FX_CURRENCIES, type FxCurrency } from "@/lib/fx.functions";
import { NativeSelect } from "@/components/native-select";

export const Route = createFileRoute("/become-a-mentor")({
  head: () => ({
    meta: [
      { title: "Стать экспертом — VirtualAccelerate MentorHub" },
      {
        name: "description",
        content: "Делитесь опытом и зарабатывайте: своя ставка, свой график, оплата и видеовстречи из коробки.",
      },
      { property: "og:title", content: "Стать экспертом — MentorHub" },
      { property: "og:description", content: "Присоединяйтесь к сообществу практиков Центральной Азии." },
    ],
  }),
  component: Become,
});

const SIGNED_URL_TTL = 60 * 60 * 24 * 365;

const schema = z.object({
  full_name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(40),
  job_title: z.string().trim().max(120),
  country: z.string().trim().min(2).max(4),
  sectors: z.array(z.string().trim().min(1).max(60)).min(1),
  short_bio: z.string().trim().max(320),
  about: z.string().trim().min(20).max(2000),
  avatar_url: z.union([z.string().trim().url().max(1000), z.literal("")]),
  linkedin_url: z.union([z.string().trim().url().max(300), z.literal("")]),
  currency: z.enum(FX_CURRENCIES),
  price_30: z.string().trim().regex(/^\d{0,8}$/),
  price_60: z.string().trim().regex(/^\d{0,8}$/),
});

type FormState = z.input<typeof schema>;

function normalizeAmount(raw: string) {
  const digits = raw.replace(/\D/g, "").slice(0, 8);
  if (digits === "") return "";
  return digits.replace(/^0+(?=\d)/, "");
}

function Become() {
  const { t, locale } = useI18n();
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [customSector, setCustomSector] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<FormState>({
    full_name: "",
    email: "",
    phone: "",
    job_title: "",
    country: "KG",
    sectors: [],
    short_bio: "",
    about: "",
    avatar_url: "",
    linkedin_url: "",
    currency: "KGS" as FxCurrency,
    price_30: "",
    price_60: "",
  });

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function toggleSector(value: string) {
    setForm((f) => ({
      ...f,
      sectors: f.sectors.includes(value) ? f.sectors.filter((s) => s !== value) : [...f.sectors, value],
    }));
  }

  function addCustomSector() {
    const v = customSector.trim().slice(0, 60);
    if (!v || form.sectors.includes(v)) return;
    setForm((f) => ({ ...f, sectors: [...f.sectors, v] }));
    setCustomSector("");
  }

  async function uploadPhoto(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error(t("admin.f.photoType"));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error(t("admin.f.photoSize"));
      return;
    }
    setUploading(true);
    const ext = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
    const path = `applications/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage
      .from("mentor-photos")
      .upload(path, file, { contentType: file.type, upsert: false });
    if (error) {
      setUploading(false);
      toast.error(error.message);
      return;
    }
    const { data, error: signErr } = await supabase.storage
      .from("mentor-photos")
      .createSignedUrl(path, SIGNED_URL_TTL);
    setUploading(false);
    if (signErr || !data?.signedUrl) {
      toast.error(signErr?.message ?? t("error"));
      return;
    }
    set("avatar_url", data.signedUrl);
    toast.success(t("admin.f.photoDone"));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(t("error"));
      return;
    }
    const v = parsed.data;
    setBusy(true);
    const { error } = await supabase.from("mentor_applications").insert({
      full_name: v.full_name,
      email: v.email.toLowerCase(),
      phone: v.phone,
      job_title: v.job_title,
      country: v.country.toUpperCase(),
      sectors: v.sectors,
      short_bio: v.short_bio,
      about: v.about,
      avatar_url: v.avatar_url || null,
      linkedin_url: v.linkedin_url || null,
      currency: v.currency,
      price_30: Number(v.price_30 || 0),
      price_60: Number(v.price_60 || 0),
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setSent(true);
    toast.success(t("become.sent"));
  }

  const benefits = [
    { icon: Coins, t: t("become.b1t"), d: t("become.b1d") },
    { icon: Users, t: t("become.b2t"), d: t("become.b2d") },
    { icon: Rocket, t: t("become.b3t"), d: t("become.b3d") },
  ];

  return (
    <Shell>
      <section className="relative overflow-hidden border-b border-border bg-card">
        <div className="aurora -left-10 top-0 h-64 w-64 bg-brand-blue/30" />
        <div className="relative mx-auto max-w-6xl px-4 py-16">
          <Reveal>
            <h1 className="max-w-2xl font-display text-3xl sm:text-4xl lg:text-5xl">{t("become.title")}</h1>
            <p className="mt-4 max-w-xl text-muted-foreground">{t("become.sub")}</p>
          </Reveal>
        </div>
      </section>

      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-[320px_1fr]">
        <div className="grid gap-5">
          {benefits.map((b, i) => (
            <Reveal key={i} delay={i * 90}>
              <div className="lift-hover flex gap-4 rounded-2xl border border-border bg-card p-6">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-brand text-primary-foreground">
                  <b.icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-semibold">{b.t}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{b.d}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <form onSubmit={submit} className="rounded-3xl border border-border bg-card p-6 shadow-glow">
            {sent ? (
              <p className="py-10 text-center text-muted-foreground">{t("become.sent")}</p>
            ) : (
              <>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label={t("admin.f.photo")} className="sm:col-span-2">
                    <div className="flex flex-wrap items-center gap-3">
                      {form.avatar_url ? (
                        <img
                          src={form.avatar_url}
                          alt={form.full_name || "avatar"}
                          className="h-16 w-16 shrink-0 rounded-2xl object-cover"
                        />
                      ) : (
                        <div className="h-16 w-16 shrink-0 rounded-2xl bg-secondary" />
                      )}
                      <input
                        ref={fileRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) void uploadPhoto(f);
                          e.target.value = "";
                        }}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        disabled={uploading}
                        onClick={() => fileRef.current?.click()}
                      >
                        <Upload className="mr-1.5 h-4 w-4" />
                        {uploading ? t("admin.f.photoUploading") : t("admin.f.photoUpload")}
                      </Button>
                      {form.avatar_url && (
                        <Button type="button" variant="ghost" onClick={() => set("avatar_url", "")}>
                          {t("admin.delete")}
                        </Button>
                      )}
                    </div>
                    <Input
                      value={form.avatar_url}
                      maxLength={1000}
                      placeholder={t("admin.f.photoUrlOptional")}
                      onChange={(e) => set("avatar_url", e.target.value)}
                    />
                  </Field>

                  <Field label={t("admin.f.name")}>
                    <Input value={form.full_name} maxLength={80} onChange={(e) => set("full_name", e.target.value)} />
                  </Field>
                  <Field label={t("admin.f.jobTitle")}>
                    <Input
                      value={form.job_title}
                      maxLength={120}
                      placeholder={t("admin.f.jobTitlePh")}
                      onChange={(e) => set("job_title", e.target.value)}
                    />
                  </Field>

                  <Field label={t("become.email")}>
                    <Input
                      type="email"
                      value={form.email}
                      maxLength={255}
                      onChange={(e) => set("email", e.target.value)}
                    />
                  </Field>
                  <Field label={t("become.phone")}>
                    <PhoneInput value={form.phone} onChange={(v) => set("phone", v.slice(0, 40))} />
                  </Field>


                  <Field label={t("admin.f.country")} className="sm:col-span-2">
                    <NativeSelect
                      value={form.country}
                      onChange={(e) => set("country", e.target.value)}
                      wrapperClassName="sm:w-56"
                    >
                      {Object.keys(COUNTRY_LABEL).map((c) => (
                        <option key={c} value={c}>
                          {COUNTRY_LABEL[c]?.[locale] ?? c}
                        </option>
                      ))}
                    </NativeSelect>
                  </Field>

                  <Field label={t("admin.f.sectors")} className="sm:col-span-2">
                    <div className="flex flex-wrap gap-2">
                      {SECTORS.map((s) => {
                        const on = form.sectors.includes(s.value) || form.sectors.includes(s[locale]);
                        return (
                          <button
                            key={s.value}
                            type="button"
                            onClick={() => toggleSector(s.value)}
                            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                              on
                                ? "border-primary bg-primary text-primary-foreground"
                                : "border-border bg-background hover:border-primary"
                            }`}
                          >
                            {s[locale]}
                          </button>
                        );
                      })}
                      {form.sectors
                        .filter((v) => !SECTORS.some((s) => s.value === v || s[locale] === v))
                        .map((v) => (
                          <button
                            key={v}
                            type="button"
                            onClick={() => toggleSector(v)}
                            className="rounded-full border border-primary bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground"
                          >
                            {v} ×
                          </button>
                        ))}
                    </div>
                    <div className="mt-2 flex gap-2">
                      <Input
                        value={customSector}
                        maxLength={60}
                        placeholder={t("admin.f.sectorCustom")}
                        onChange={(e) => setCustomSector(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addCustomSector();
                          }
                        }}
                      />
                      <Button type="button" variant="outline" onClick={addCustomSector}>
                        +
                      </Button>
                    </div>
                  </Field>

                  <Field label={t("admin.f.shortBio")} className="sm:col-span-2">
                    <Textarea
                      rows={3}
                      value={form.short_bio}
                      maxLength={320}
                      placeholder={t("admin.f.shortBioPh")}
                      onChange={(e) => set("short_bio", e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">{form.short_bio.length}/320</p>
                  </Field>

                  <Field label={t("become.about")} className="sm:col-span-2">
                    <Textarea
                      rows={6}
                      value={form.about}
                      maxLength={2000}
                      onChange={(e) => set("about", e.target.value)}
                    />
                  </Field>

                  <Field label="LinkedIn" className="sm:col-span-2">
                    <Input
                      value={form.linkedin_url}
                      maxLength={300}
                      placeholder="https://linkedin.com/in/…"
                      onChange={(e) => set("linkedin_url", e.target.value)}
                    />
                  </Field>

                  <Field label={t("admin.f.currency")} className="sm:col-span-2">
                    <NativeSelect
                      value={form.currency}
                      onChange={(e) => set("currency", e.target.value as FxCurrency)}
                      wrapperClassName="sm:w-56"
                    >
                      {FX_CURRENCIES.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </NativeSelect>
                  </Field>

                  <Field label={t("admin.f.price30")}>
                    <Input
                      inputMode="numeric"
                      maxLength={8}
                      value={form.price_30}
                      onChange={(e) => set("price_30", normalizeAmount(e.target.value))}
                    />
                  </Field>
                  <Field label={t("admin.f.price60")}>
                    <Input
                      inputMode="numeric"
                      maxLength={8}
                      value={form.price_60}
                      onChange={(e) => set("price_60", normalizeAmount(e.target.value))}
                    />
                  </Field>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={busy || uploading}
                  className="mt-5 w-full bg-gradient-brand text-primary-foreground"
                >
                  {t("become.send")}
                </Button>
              </>
            )}
          </form>
        </Reveal>
      </div>
    </Shell>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
