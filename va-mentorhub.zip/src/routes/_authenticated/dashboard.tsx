import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarPlus, Video } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site-chrome";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { useSession } from "@/lib/session";
import { useCurrency } from "@/lib/currency";
import {
  formatDateTime,
  googleCalendarUrl,
} from "@/lib/mentorhub";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Мои сессии — VirtualAccelerate MentorHub" },
      { name: "description", content: "Личный кабинет клиента: бронирования, оплата, ссылки на встречи." },
      { property: "og:title", content: "Мои сессии — MentorHub" },
      { property: "og:description", content: "Управляйте своими сессиями с экспертами." },
    ],
  }),
  component: Dashboard,
});

type BookingRow = {
  id: string;
  starts_at: string;
  ends_at: string;
  amount: number;
  currency: string;
  status: string;
  topic: string;
  meet_url: string | null;
  duration_min: number;
  request_status: string;
  contact_name: string;
  contact_phone: string;
  contact_method: string;
  preferred_time: string;
  client_note: string;
  mentors: { full_name: string; slug: string } | null;
};

function Dashboard() {
  const { t, locale } = useI18n();
  const { user } = useSession();
  const { display } = useCurrency();
  const qc = useQueryClient();

  const bookings = useQuery({
    queryKey: ["my-bookings", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*, mentors(full_name, slug)")
        .eq("client_id", user!.id)
        .order("starts_at");
      if (error) throw error;
      return (data ?? []) as unknown as BookingRow[];
    },
  });

  async function cancel(b: BookingRow) {
    const { error } = await supabase.from("bookings").update({ status: "cancelled" }).eq("id", b.id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["my-bookings", user?.id] });
    toast.success(t("booking.cancelled"));
  }

  const now = Date.now();
  const all = bookings.data ?? [];
  const isPast = (b: BookingRow) =>
    b.status === "cancelled" ||
    b.status === "completed" ||
    b.request_status === "completed" ||
    b.request_status === "cancelled" ||
    b.request_status === "declined" ||
    // прошедшие только если время согласовано (заявка запланирована/подтверждена)
    ((b.request_status === "scheduled" || b.request_status === "confirmed" || b.status === "confirmed") &&
      new Date(b.starts_at).getTime() < now);
  const upcoming = all.filter((b) => !isPast(b));
  const past = all.filter(isPast);

  const Card = ({ b }: { b: BookingRow }) => (
    <div className="lift-hover rounded-2xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-lg font-semibold">{b.mentors?.full_name ?? "—"}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{b.topic || "—"}</p>
        </div>
        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold ${
            b.status === "confirmed"
              ? "bg-primary/12 text-primary-deep"
              : b.status === "cancelled"
                ? "bg-destructive/10 text-destructive"
                : "bg-secondary text-secondary-foreground"
          }`}
        >
          {t(`status.${b.status}`)}
        </span>
      </div>

      <dl className="mt-4 grid gap-1 text-sm text-muted-foreground sm:grid-cols-2">
        <div>
          {t("booking.when")}: <b className="text-foreground">{formatDateTime(b.starts_at, locale)}</b>
        </div>
        <div>
          {t("booking.amount")}: <b className="text-foreground">{display(b.amount, b.currency, locale)}</b>{" "}
          · {b.duration_min === 30 ? t("book.min30") : t("book.min60")}
        </div>
        <div>
          {t("book.reqStatus")}: <b className="text-foreground">{t(`reqstatus.${b.request_status}`)}</b>
        </div>
        {b.preferred_time ? (
          <div>
            {t("book.preferred")}: <b className="text-foreground">{b.preferred_time}</b>
          </div>
        ) : null}
      </dl>

      <div className="mt-5 flex flex-wrap gap-2">
        {b.status === "pending_payment" && (
          <span className="self-center text-xs text-muted-foreground">{t("book.contactNote")}</span>
        )}
        {b.meet_url ? (
          <Button asChild size="sm" variant="outline">
            <a href={b.meet_url} target="_blank" rel="noreferrer">
              <Video className="mr-1.5 h-4 w-4" />
              {t("booking.meet")}
            </a>
          </Button>
        ) : (
          <span className="self-center text-xs text-muted-foreground">{t("booking.meetPending")}</span>
        )}
        {b.status === "confirmed" && (
          <Button asChild size="sm" variant="outline">
            <a
              href={googleCalendarUrl({
                title: `MentorHub: ${b.mentors?.full_name ?? ""}`,
                details: b.topic,
                startsAt: b.starts_at,
                endsAt: b.ends_at,
                ...(b.meet_url ? { location: b.meet_url } : {}),
              })}
              target="_blank"
              rel="noreferrer"
            >
              <CalendarPlus className="mr-1.5 h-4 w-4" />
              {t("booking.calendar")}
            </a>
          </Button>
        )}
        {b.status !== "cancelled" && b.status !== "completed" && (
          <Button size="sm" variant="ghost" onClick={() => cancel(b)}>
            {t("booking.cancel")}
          </Button>
        )}
      </div>
    </div>
  );

  return (
    <Shell>
      <div className="mx-auto max-w-5xl px-4 py-12">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="font-display text-3xl">{t("dash.title")}</h1>
          <Button asChild variant="outline">
            <Link to="/mentors">{t("dash.find")}</Link>
          </Button>
        </div>

        <p className="mt-3 rounded-xl border border-dashed border-border p-3 text-xs text-muted-foreground">
          {t("booking.demoNote")}
        </p>

        <h2 className="mt-10 font-display text-xl">{t("dash.upcoming")}</h2>
        <div className="mt-4 space-y-4">
          {upcoming.map((b) => (
            <Card key={b.id} b={b} />
          ))}
          {!upcoming.length && <p className="text-sm text-muted-foreground">{t("dash.empty")}</p>}
        </div>

        {past.length > 0 && (
          <>
            <h2 className="mt-12 font-display text-xl">{t("dash.past")}</h2>
            <div className="mt-4 space-y-4 opacity-80">
              {past.map((b) => (
                <Card key={b.id} b={b} />
              ))}
            </div>
          </>
        )}
      </div>
    </Shell>
  );
}
