import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site-chrome";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { useSession } from "@/lib/session";
import { formatDateTime, formatPrice, type Mentor } from "@/lib/mentorhub";

export const Route = createFileRoute("/_authenticated/mentor-cabinet")({
  head: () => ({
    meta: [
      { title: "Кабинет эксперта — VirtualAccelerate MentorHub" },
      { name: "description", content: "Управляйте профилем, ставкой, расписанием слотов и заявками клиентов." },
      { property: "og:title", content: "Кабинет эксперта — MentorHub" },
      { property: "og:description", content: "Профиль, расписание и заявки в одном месте." },
    ],
  }),
  component: MentorCabinet,
});

function BookingContacts({ b }: { b: Record<string, string> }) {
  const { t } = useI18n();
  const bits = [b["contact_name"], b["contact_phone"], b["contact_email"]].filter(Boolean);
  if (!bits.length) return null;
  return (
    <div className="mt-1 space-y-0.5 text-xs text-muted-foreground">
      <div>
        {t("book.contacts")}: {bits.join(" · ")}
        {b["contact_method"] ? ` (${t(`book.method.${b["contact_method"]}`)})` : ""}
      </div>
      {b["preferred_time"] ? <div>{t("book.preferred")}: {b["preferred_time"]}</div> : null}
      {b["client_note"] ? <div>{b["client_note"]}</div> : null}
    </div>
  );
}

function MentorCabinet() {
  const { t, locale } = useI18n();
  const { user } = useSession();
  const qc = useQueryClient();

  const mentorQ = useQuery({
    queryKey: ["me-mentor", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("mentors").select("*").eq("user_id", user!.id).maybeSingle();
      if (error) throw error;
      return data as unknown as Mentor | null;
    },
  });
  const mentor = mentorQ.data;

  const slotsQ = useQuery({
    queryKey: ["me-slots", mentor?.id],
    enabled: !!mentor?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("mentor_slots")
        .select("*")
        .eq("mentor_id", mentor!.id)
        .order("starts_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  const bookingsQ = useQuery({
    queryKey: ["me-mentor-bookings", mentor?.id],
    enabled: !!mentor?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .eq("mentor_id", mentor!.id)
        .order("starts_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  const [form, setForm] = useState({ headline_ru: "", headline_en: "", bio_ru: "", bio_en: "", price: 0 });
  const [slotStart, setSlotStart] = useState("");

  useEffect(() => {
    if (mentor) {
      setForm({
        headline_ru: mentor.headline_ru,
        headline_en: mentor.headline_en,
        bio_ru: mentor.bio_ru,
        bio_en: mentor.bio_en,
        price: mentor.price_per_hour,
      });
    }
  }, [mentor]);

  if (mentorQ.isLoading) {
    return (
      <Shell>
        <div className="mx-auto max-w-5xl px-4 py-24 text-muted-foreground">{t("loading")}</div>
      </Shell>
    );
  }

  if (!mentor) {
    return (
      <Shell>
        <div className="mx-auto max-w-2xl px-4 py-24 text-center">
          <h1 className="font-display text-2xl">{t("mc.title")}</h1>
          <p className="mt-4 text-muted-foreground">{t("mc.noProfile")}</p>
        </div>
      </Shell>
    );
  }

  async function save() {
    const { error } = await supabase
      .from("mentors")
      .update({
        headline_ru: form.headline_ru,
        headline_en: form.headline_en,
        bio_ru: form.bio_ru,
        bio_en: form.bio_en,
        price_per_hour: Number(form.price) || 0,
      })
      .eq("id", mentor!.id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["me-mentor", user?.id] });
    toast.success(t("mc.saved"));
  }

  async function addSlot() {
    if (!slotStart) return;
    const start = new Date(slotStart);
    const end = new Date(start.getTime() + 60 * 60 * 1000);
    const { error } = await supabase
      .from("mentor_slots")
      .insert({ mentor_id: mentor!.id, starts_at: start.toISOString(), ends_at: end.toISOString() });
    if (error) { toast.error(error.message); return; }
    setSlotStart("");
    qc.invalidateQueries({ queryKey: ["me-slots", mentor!.id] });
  }

  async function removeSlot(id: string) {
    const { error } = await supabase.from("mentor_slots").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["me-slots", mentor!.id] });
  }

  async function complete(id: string) {
    const { error } = await supabase.from("bookings").update({ status: "completed" }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["me-mentor-bookings", mentor!.id] });
  }

  return (
    <Shell>
      <div className="mx-auto max-w-5xl px-4 py-12">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="font-display text-3xl">{t("mc.title")}</h1>
          <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">
            {t("mc.published")}: {mentor.is_published ? "✓" : "—"}
          </span>
        </div>

        <section className="mt-8 rounded-3xl border border-border bg-card p-6">
          <h2 className="font-display text-xl">{t("mc.profile")}</h2>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            <Input
              value={form.headline_ru}
              maxLength={140}
              onChange={(e) => setForm({ ...form, headline_ru: e.target.value })}
              placeholder="Headline RU"
            />
            <Input
              value={form.headline_en}
              maxLength={140}
              onChange={(e) => setForm({ ...form, headline_en: e.target.value })}
              placeholder="Headline EN"
            />
            <Textarea
              rows={5}
              maxLength={2000}
              value={form.bio_ru}
              onChange={(e) => setForm({ ...form, bio_ru: e.target.value })}
              placeholder="Bio RU"
            />
            <Textarea
              rows={5}
              maxLength={2000}
              value={form.bio_en}
              onChange={(e) => setForm({ ...form, bio_en: e.target.value })}
              placeholder="Bio EN"
            />
            <label className="flex items-center gap-3 text-sm">
              <span className="text-muted-foreground">{t("mc.price")}</span>
              <Input
                type="number"
                min={0}
                value={form.price}
                onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                className="w-32"
              />
              <span className="text-muted-foreground">{mentor.currency}</span>
            </label>
          </div>
          <Button onClick={save} className="mt-5 bg-gradient-brand text-primary-foreground">
            {t("mc.save")}
          </Button>
        </section>

        <section className="mt-6 rounded-3xl border border-border bg-card p-6">
          <h2 className="font-display text-xl">{t("mc.schedule")}</h2>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Input
              type="datetime-local"
              value={slotStart}
              onChange={(e) => setSlotStart(e.target.value)}
              className="w-64"
            />
            <Button onClick={addSlot} variant="outline">
              <Plus className="mr-1.5 h-4 w-4" />
              {t("mc.addSlot")}
            </Button>
          </div>
          <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {(slotsQ.data ?? []).map((s) => (
              <div
                key={s.id}
                className="flex items-center justify-between rounded-xl border border-border px-3 py-2 text-sm"
              >
                <span className={s.is_booked ? "text-muted-foreground line-through" : ""}>
                  {formatDateTime(s.starts_at, locale)}
                </span>
                {!s.is_booked && (
                  <button onClick={() => removeSlot(s.id)} className="text-muted-foreground hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </section>

        <section className="mt-6 rounded-3xl border border-border bg-card p-6">
          <h2 className="font-display text-xl">{t("mc.requests")}</h2>
          <div className="mt-5 space-y-3">
            {(bookingsQ.data ?? []).map((b) => (
              <div
                key={b.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border p-4 text-sm"
              >
                <div className="min-w-0">
                  <div className="font-medium">
                    {formatDateTime(b.starts_at, locale)} ·{" "}
                    {(b as unknown as { duration_min?: number }).duration_min === 30
                      ? t("book.min30")
                      : t("book.min60")}
                  </div>
                  <div className="text-muted-foreground">{b.topic || "—"}</div>
                  <BookingContacts b={b as unknown as Record<string, string>} />
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold">{formatPrice(b.amount, b.currency, locale)}</span>
                  <span className="rounded-full bg-secondary px-3 py-1 text-xs">
                    {t(`reqstatus.${(b as unknown as { request_status?: string }).request_status ?? "new"}`)}
                  </span>
                  {b.status === "confirmed" && (
                    <Button size="sm" variant="outline" onClick={() => complete(b.id)}>
                      {t("mc.markDone")}
                    </Button>
                  )}
                </div>
              </div>
            ))}
            {!bookingsQ.data?.length && <p className="text-sm text-muted-foreground">{t("dash.empty")}</p>}
          </div>
        </section>
      </div>
    </Shell>
  );
}
