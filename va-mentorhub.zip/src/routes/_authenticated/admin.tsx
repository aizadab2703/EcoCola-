import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { CalendarPlus, ChevronDown, Copy, Mail, Trash2 } from "lucide-react";
import { transliterateName } from "@/lib/translit";
import { toast } from "sonner";
import { Shell } from "@/components/site-chrome";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { MentorFormDialog, type MentorFormPrefill } from "@/components/admin-mentor-form";
import { useI18n } from "@/lib/i18n";
import { useRoles } from "@/lib/session";
import { enSourceHash, formatDateTime, formatPrice, type Mentor } from "@/lib/mentorhub";
import { translateMentorProfile } from "@/lib/translate.functions";
import { useServerFn } from "@tanstack/react-start";
import { NativeSelect } from "@/components/native-select";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Админ-панель — VirtualAccelerate MentorHub" },
      { name: "description", content: "Модерация экспертов, приглашения по email, бронирования и выручка платформы." },
      { property: "og:title", content: "Админ-панель — MentorHub" },
      { property: "og:description", content: "Управление платформой MentorHub." },
    ],
  }),
  component: Admin,
});

type BookingRow = {
  id: string;
  mentor_id?: string;
  starts_at: string;

  created_at: string;
  amount: number;
  currency: string;
  duration_min?: number;
  topic?: string;
  contact_name?: string;
  contact_email?: string;
  contact_phone?: string;
  contact_method?: string;
  preferred_time?: string;
  client_note?: string;
  request_status?: ReqStatus;
  scheduled_at?: string | null | undefined;
  scheduled_timezone?: string | null | undefined;
  meet_url?: string | null | undefined;
  mentors?: { full_name?: string } | null;
};

const REQ_STATUSES = ["new", "contacted", "scheduled", "confirmed", "completed", "cancelled", "declined"] as const;
type ReqStatus = (typeof REQ_STATUSES)[number];

const TIMEZONES = ["Asia/Bishkek", "Asia/Almaty", "Asia/Tashkent", "Asia/Dushanbe", "Europe/Moscow", "UTC"];

function zonedToUtc(dateStr: string, timeStr: string, tz: string) {
  const naive = new Date(`${dateStr}T${timeStr}:00Z`);
  const shifted = new Date(naive.toLocaleString("en-US", { timeZone: tz }));
  return new Date(naive.getTime() + (naive.getTime() - shifted.getTime()));
}

function gcalStamp(d: Date) {
  return d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
}

function calendarUrl(b: BookingRow, mentorName: string, details: string, mentorEmail?: string) {
  const start = b.scheduled_at ? new Date(b.scheduled_at) : new Date(b.starts_at);
  const end = new Date(start.getTime() + (b.duration_min ?? 60) * 60000);
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: `MentorHub: ${mentorName} × ${b.contact_name || "client"}`,
    dates: `${gcalStamp(start)}/${gcalStamp(end)}`,
    details,
    ctz: b.scheduled_timezone || "Asia/Bishkek",
  });
  const attendees = new Set<string>();
  if (b.contact_email?.trim()) attendees.add(b.contact_email.trim().toLowerCase());
  if (mentorEmail?.trim()) attendees.add(mentorEmail.trim().toLowerCase());
  attendees.forEach((email) => params.append("add", email));
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}


async function copy(value: string, msg: string) {
  await navigator.clipboard.writeText(value);
  toast.success(msg);
}

function Row({ label, value, onCopy }: { label: string; value?: string | null | undefined; onCopy?: (() => void) | undefined }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-border pb-2">
      <dt className="text-xs uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="flex min-w-0 items-center gap-2 text-right">
        <span className="break-words">{value || "—"}</span>
        {onCopy && (
          <button type="button" onClick={onCopy} aria-label={label} className="text-muted-foreground hover:text-foreground">
            <Copy className="h-3.5 w-3.5" />
          </button>
        )}
      </dd>
    </div>
  );
}

function Admin() {
  const { t, locale } = useI18n();
  const { isAdmin } = useRoles();
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"mentor" | "admin" | "client">("mentor");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Mentor | null>(null);
  const [prefill, setPrefill] = useState<MentorFormPrefill | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [openApp, setOpenApp] = useState<string | null>(null);
  const [translatingAll, setTranslatingAll] = useState(false);
  const [mentorSearch, setMentorSearch] = useState("");
  const translate = useServerFn(translateMentorProfile);

  const mentorsQ = useQuery({
    queryKey: ["admin-mentors"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase.from("mentors").select("*").order("full_name");
      if (error) throw error;
      return (data ?? []) as unknown as Mentor[];
    },
  });

  /** Backfill: translate mentors whose EN copy is missing or stale. */
  async function translateAllMentors() {
    const all = mentorsQ.data ?? [];
    setTranslatingAll(true);
    let done = 0;
    for (const m of all) {
      const hash = enSourceHash([
        m.job_title ?? "",
        m.short_bio_ru ?? "",
        m.bio_ru ?? "",
        (m.expertise ?? []).join(","),
      ]);
      const missingEn =
        !m.full_name_en ||
        !m.job_title_en ||
        !m.bio_en ||
        m.bio_en === m.bio_ru ||
        (m.short_bio_ru ? !m.short_bio_en || m.short_bio_en === m.short_bio_ru : false);
      if (m.en_source_hash === hash && !missingEn) continue;
      try {
        const auto = await translate({
          data: {
            job_title: m.job_title ?? "",
            short_bio: m.short_bio_ru ?? "",
            bio: m.bio_ru ?? "",
            sectors: m.expertise ?? [],
          },
        });
        await supabase
          .from("mentors")
          .update({
            full_name_en: m.full_name_en || transliterateName(m.full_name),
            job_title_en: auto.job_title_en || m.job_title || "",
            short_bio_en: auto.short_bio_en || m.short_bio_ru || "",
            bio_en: auto.bio_en || m.bio_ru || "",
            expertise_en: auto.sectors_en,
            en_source_hash: hash,
          })
          .eq("id", m.id);
        done += 1;
      } catch {
        /* keep going with the rest */
      }
    }
    setTranslatingAll(false);
    qc.invalidateQueries({ queryKey: ["admin-mentors"] });
    qc.invalidateQueries({ queryKey: ["mentors"] });
    toast.success(`${t("admin.translateAllDone")} (${done})`);
  }


  const bookingsQ = useQuery({
    queryKey: ["admin-bookings"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*, mentors(full_name)")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  const mentorEmailsQ = useQuery({
    queryKey: ["admin-mentor-emails"],
    enabled: isAdmin,
    queryFn: async () => {
      const [apps, profiles] = await Promise.all([
        supabase.from("mentor_applications").select("full_name, email"),
        supabase.from("profiles").select("id, email"),
      ]);
      return {
        apps: (apps.data ?? []) as { full_name: string; email: string }[],
        profiles: (profiles.data ?? []) as { id: string; email: string | null }[],
      };
    },
  });

  function mentorEmailFor(mentorId?: string) {
    if (!mentorId) return "";
    const m = (mentorsQ.data ?? []).find((x) => x.id === mentorId);
    if (!m) return "";
    const byApp = (mentorEmailsQ.data?.apps ?? []).find(
      (a) => a.full_name.trim().toLowerCase() === m.full_name.trim().toLowerCase(),
    )?.email;
    const byProfile = m.user_id
      ? (mentorEmailsQ.data?.profiles ?? []).find((p) => p.id === m.user_id)?.email
      : null;
    return (m.email || byApp || byProfile || "").trim();

  }



  async function setRequestStatus(id: string, value: string) {
    const { error } = await supabase
      .from("bookings")
      .update({ request_status: value as ReqStatus })
      .eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["admin-bookings"] });
    toast.success(t("admin.saved"));
  }

  const invitesQ = useQuery({
    queryKey: ["admin-invites"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invitations")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const appsQ = useQuery({
    queryKey: ["admin-applications"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("mentor_applications")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  async function setAppStatus(id: string, status: "approved" | "rejected") {
    const { error } = await supabase.from("mentor_applications").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["admin-applications"] });
    toast.success(t("admin.saved"));
  }

  async function setStatus(m: Mentor, status: "pending" | "active" | "paused") {
    const { error } = await supabase.from("mentors").update({ status }).eq("id", m.id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["admin-mentors"] });
    toast.success(t("admin.saved"));
  }

  async function removeMentor(id: string, name: string) {
    if (!window.confirm(t("admin.deleteMentorConfirm").replace("{name}", name))) return;
    const { error } = await supabase.from("mentors").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["admin-mentors"] });
    toast.success(t("admin.mentorDeleted"));
  }

  if (!isAdmin) {
    return (
      <Shell>
        <div className="mx-auto max-w-2xl px-4 py-24 text-center">
          <h1 className="font-display text-2xl">{t("admin.noAccess")}</h1>
        </div>
      </Shell>
    );
  }

  const revenue = (bookingsQ.data ?? [])
    .filter((b) => b.status === "confirmed" || b.status === "completed")
    .reduce((sum, b) => sum + Number(b.amount), 0);

  async function ensureInvitation(email: string, role: "mentor" | "admin" | "client" = "mentor") {
    const normalized = email.trim().toLowerCase();
    const { data: existing } = await supabase
      .from("invitations")
      .select("id")
      .eq("email", normalized)
      .eq("status", "pending")
      .maybeSingle();

    if (existing) {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      const token = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
      const { error } = await supabase.from("invitations").update({ token }).eq("id", existing.id);
      return { ok: !error, error, resent: true };
    }

    const { error } = await supabase.from("invitations").insert({ email: normalized, role });
    return { ok: !error, error, resent: false };
  }

  async function invite() {
    if (!email.trim()) return;
    const { ok, error, resent } = await ensureInvitation(email, role);
    if (error) { toast.error(error.message); return; }
    setEmail("");
    qc.invalidateQueries({ queryKey: ["admin-invites"] });
    toast.success(t(resent ? "admin.inviteResent" : "admin.inviteSent"));
  }

  async function revoke(id: string) {
    const { error } = await supabase.from("invitations").update({ status: "revoked" }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["admin-invites"] });
  }

  /** Removes only the invitation record; the mentor profile stays untouched. */
  async function deleteInvite(id: string, email: string) {
    if (!window.confirm(t("admin.deleteInviteConfirm").replace("{email}", email))) return;
    const { error } = await supabase.from("invitations").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    qc.invalidateQueries({ queryKey: ["admin-invites"] });
    toast.success(t("admin.inviteDeleted"));
  }

  async function resendMentorInvite(email: string) {
    const { ok, error } = await ensureInvitation(email, "mentor");
    if (error) { toast.error(error.message); return; }
    if (ok) {
      qc.invalidateQueries({ queryKey: ["admin-invites"] });
      toast.success(t("admin.inviteResent"));
    }
  }

  function copyLink(token: string) {
    void navigator.clipboard.writeText(`${window.location.origin}/auth?invite=${token}`);
    toast.success(t("admin.copied"));
  }

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-12">
        <h1 className="font-display text-3xl">{t("admin.title")}</h1>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            { label: t("admin.mentors"), value: mentorsQ.data?.length ?? 0 },
            { label: t("admin.bookings"), value: bookingsQ.data?.length ?? 0 },
            { label: t("admin.revenue"), value: formatPrice(revenue, "USD", locale) },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-border bg-card p-5">
              <div className="text-sm text-muted-foreground">{s.label}</div>
              <div className="mt-1 font-display text-2xl font-bold text-gradient-brand">{s.value}</div>
            </div>
          ))}
        </div>

        <section className="mt-8 rounded-3xl border border-border bg-card p-6">
          <h2 className="flex items-center gap-2 font-display text-xl">
            <Mail className="h-5 w-5 text-primary" />
            {t("admin.invites")}
          </h2>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Input
              type="email"
              maxLength={255}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="mentor@example.com"
              className="w-72"
            />
            <NativeSelect
              value={role}
              onChange={(e) => setRole(e.target.value as typeof role)}
              wrapperClassName="w-40"
            >
              <option value="mentor">mentor</option>
              <option value="client">client</option>
              <option value="admin">admin</option>
            </NativeSelect>
            <Button onClick={invite} className="bg-gradient-brand text-primary-foreground">
              {t("admin.invite")}
            </Button>
          </div>

          <div className="mt-5 space-y-2">
            {(invitesQ.data ?? []).map((i) => (
              <div
                key={i.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border p-3 text-sm"
              >
                <div>
                  <span className="font-medium">{i.email}</span>
                  <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-xs">{i.role}</span>
                  <span className="ml-2 text-xs text-muted-foreground">{i.status}</span>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => copyLink(i.token)}>
                    <Copy className="mr-1.5 h-3.5 w-3.5" />
                    {t("admin.copyLink")}
                  </Button>
                  {i.status === "pending" && (
                    <Button size="sm" variant="ghost" onClick={() => revoke(i.id)}>
                      {t("admin.revoke")}
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-destructive"
                    onClick={() => deleteInvite(i.id, i.email)}
                  >
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                    {t("admin.deleteInvite")}
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <h3 className="mt-8 font-display text-base">{t("admin.invitedMentors")}</h3>
          <div className="mt-3 space-y-2">
            {(mentorsQ.data ?? []).filter((m) => m.email).length === 0 && (
              <p className="text-sm text-muted-foreground">{t("admin.noInvitedMentors")}</p>
            )}
            {(mentorsQ.data ?? [])
              .filter((m) => m.email)
              .map((m) => {
                const inv = (invitesQ.data ?? []).find(
                  (i) => i.email?.toLowerCase() === m.email!.toLowerCase(),
                );
                return (
                  <div
                    key={m.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border p-3 text-sm"
                  >
                    <div className="min-w-0">
                      <span className="font-medium">{m.full_name}</span>
                      <span className="ml-2 break-all text-muted-foreground">{m.email}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full bg-secondary px-2 py-0.5 text-xs">
                        {inv ? inv.status : t("admin.inviteNotSent")}
                      </span>
                      <Button size="sm" variant="outline" onClick={() => resendMentorInvite(m.email!)}>
                        <Mail className="mr-1.5 h-3.5 w-3.5" />
                        {t("admin.resendInvite")}
                      </Button>
                      {inv && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => deleteInvite(inv.id, m.email!)}
                        >
                          <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                          {t("admin.deleteInvite")}
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </section>

        <section className="mt-6 rounded-3xl border border-border bg-card p-6">
          <h2 className="font-display text-xl">{t("admin.applications")}</h2>
          <div className="mt-4 space-y-2">
            {(appsQ.data ?? []).length === 0 && (
              <p className="text-sm text-muted-foreground">{t("admin.appEmpty")}</p>
            )}
            {(appsQ.data ?? []).map((a: AppRow) => {
              const open = openApp === a.id;
              return (
                <div key={a.id} className="rounded-xl border border-border text-sm">
                  <button
                    type="button"
                    onClick={() => setOpenApp(open ? null : a.id)}
                    className="flex w-full flex-wrap items-center justify-between gap-3 p-3 text-left"
                  >
                    <span className="flex min-w-0 items-center gap-3">
                      {a.avatar_url ? (
                        <img src={a.avatar_url} alt={a.full_name} className="h-10 w-10 rounded-xl object-cover" />
                      ) : (
                        <span className="h-10 w-10 rounded-xl bg-secondary" />
                      )}
                      <span className="min-w-0">
                        <span className="block truncate font-medium">{a.full_name}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {a.job_title || a.email}
                        </span>
                      </span>
                    </span>
                    <span className="flex items-center gap-2">
                      <span className="rounded-full bg-secondary px-2 py-0.5 text-xs">{a.status}</span>
                      <ChevronDown
                        className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`}
                      />
                    </span>
                  </button>

                  {open && (
                    <div className="grid gap-2 border-t border-border p-3 sm:grid-cols-2">
                      <AppRowItem label={t("become.email")} value={a.email} />
                      <AppRowItem label={t("become.phone")} value={a.phone || "—"} />
                      <AppRowItem label={t("admin.f.jobTitle")} value={a.job_title || "—"} />
                      <AppRowItem label={t("admin.f.country")} value={a.country || "—"} />
                      <AppRowItem
                        label={t("admin.f.sectors")}
                        value={(a.sectors ?? []).length ? (a.sectors ?? []).join(", ") : "—"}
                      />
                      <AppRowItem label="LinkedIn" value={a.linkedin_url || "—"} />
                      <AppRowItem
                        label={t("admin.f.price30")}
                        value={a.price_30 ? formatPrice(a.price_30, a.currency ?? "KGS", locale) : "—"}
                      />
                      <AppRowItem
                        label={t("admin.f.price60")}
                        value={a.price_60 ? formatPrice(a.price_60, a.currency ?? "KGS", locale) : "—"}
                      />
                      <AppRowItem label={t("admin.f.shortBio")} value={a.short_bio || "—"} className="sm:col-span-2" />
                      <AppRowItem label={t("become.about")} value={a.about || "—"} className="sm:col-span-2" />
                      <AppRowItem
                        label={t("admin.created")}
                        value={formatDateTime(a.created_at, locale)}
                        className="sm:col-span-2"
                      />

                      <div className="flex flex-wrap gap-2 sm:col-span-2">
                        <Button
                          size="sm"
                          className="bg-gradient-brand text-primary-foreground"
                          onClick={() => {
                            setEditing(null);
                            setPrefill({
                              full_name: a.full_name,
                              job_title: a.job_title ?? "",
                              country: a.country || "KG",
                              sectors: a.sectors ?? [],
                              short_bio_ru: a.short_bio ?? "",
                              bio_ru: a.about ?? "",
                              avatar_url: a.avatar_url ?? "",
                              linkedin_url: a.linkedin_url ?? "",
                              currency: (a.currency ?? "KGS") as never,
                              price_30: String(a.price_30 ?? 0),
                              price_60: String(a.price_60 ?? 0),
                              invite_email: a.email,
                            });
                            setFormOpen(true);
                          }}
                        >
                          {t("admin.appToMentor")}
                        </Button>
                        {a.status === "new" && (
                          <>
                            <Button size="sm" variant="outline" onClick={() => setAppStatus(a.id, "approved")}>
                              {t("admin.approve")}
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => setAppStatus(a.id, "rejected")}>
                              {t("admin.reject")}
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>


        <section className="mt-6 rounded-3xl border border-border bg-card p-6">
          <h2 className="font-display text-xl">{t("admin.mentors")}</h2>

          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <Button
              className="w-full bg-gradient-brand text-primary-foreground sm:w-auto"
              onClick={() => { setEditing(null); setFormOpen(true); }}
            >
              {t("admin.addMentor")}
            </Button>
            <Button
              variant="outline"
              className="w-full sm:w-auto"
              disabled={translatingAll}
              onClick={translateAllMentors}
            >
              {translatingAll ? t("admin.f.trBusy") : t("admin.translateAll")}
            </Button>
          </div>

          <div className="mt-4">
            <Input
              value={mentorSearch}
              onChange={(e) => setMentorSearch(e.target.value)}
              placeholder={t("admin.mentorSearch")}
              className="w-full sm:w-96"
            />
          </div>

          <div className="mt-4 space-y-2">
            {(() => {
              const query = mentorSearch.trim().toLowerCase();
              const list = (mentorsQ.data ?? []).filter((m) => {
                if (!query) return true;
                const haystack = [
                  m.full_name,
                  m.job_title,
                  m.job_title_en,
                  m.email,
                  m.country,
                  m.category_slug,
                  ...(m.expertise ?? []),
                  ...(m.expertise_en ?? []),
                ]
                  .filter(Boolean)
                  .join(" ")
                  .toLowerCase();
                return haystack.includes(query);
              });
              if (list.length === 0) {
                return <p className="text-sm text-muted-foreground">{t("admin.mentorEmpty")}</p>;
              }
              return list.map((m) => (
                <div
                  key={m.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border p-3 text-sm"
                >
                  <div>
                    <span className="font-medium">{m.full_name}</span>
                    <span className="ml-2 text-muted-foreground">{m.category_slug}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full bg-secondary px-2 py-0.5 text-xs">
                      {t(`status.${m.status ?? (m.is_published ? "active" : "pending")}`)}
                    </span>
                    <span className="font-semibold">{formatPrice(m.price_60 ?? m.price_per_hour, m.currency, locale)}</span>
                    <Button size="sm" variant="outline" onClick={() => { setEditing(m); setFormOpen(true); }}>
                      {t("admin.edit")}
                    </Button>
                    {m.status === "active" ? (
                      <Button size="sm" variant="outline" onClick={() => setStatus(m, "paused")}>
                        {t("admin.pause")}
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => setStatus(m, "active")}>
                        {t("admin.publish")}
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => removeMentor(m.id, m.full_name)}>
                      {t("admin.delete")}
                    </Button>
                  </div>
                </div>
              ));
            })()}
          </div>
        </section>

        <section className="mt-6 rounded-3xl border border-border bg-card p-6">
          <h2 className="font-display text-xl">{t("admin.bookings")}</h2>
          <div className="mt-4 space-y-3">
            {(bookingsQ.data ?? []).map((raw) => {
              const b = raw as unknown as BookingRow;
              return (
                <BookingCard
                  key={b.id}
                  b={b}
                  mentorEmail={mentorEmailFor(b.mentor_id)}

                  open={openId === b.id}
                  onToggle={() => setOpenId(openId === b.id ? null : b.id)}
                  onStatus={(v) => setRequestStatus(b.id, v)}
                  onSaved={() => qc.invalidateQueries({ queryKey: ["admin-bookings"] })}
                />
              );
            })}
            {!bookingsQ.data?.length && <p className="text-sm text-muted-foreground">{t("admin.b.empty")}</p>}
          </div>
        </section>
      </div>


      {formOpen && (
        <MentorFormDialog
          key={editing?.id ?? (prefill ? "prefill" : "new")}
          open={formOpen}
          onOpenChange={(v) => { setFormOpen(v); if (!v) setPrefill(null); }}
          mentor={editing}
          prefill={prefill}
        />
      )}
    </Shell>
  );
}

type AppRow = {
  id: string;
  full_name: string;
  email: string;
  about: string | null;
  status: string;
  created_at: string;
  phone?: string | null;
  job_title?: string | null;
  country?: string | null;
  sectors?: string[] | null;
  short_bio?: string | null;
  avatar_url?: string | null;
  linkedin_url?: string | null;
  currency?: string | null;
  price_30?: number | null;
  price_60?: number | null;
};

function AppRowItem({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className={className}>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="whitespace-pre-wrap break-words">{value}</p>
    </div>
  );
}


function BookingCard({
  b,
  mentorEmail,
  open,
  onToggle,
  onStatus,
  onSaved,
}: {
  b: BookingRow;
  mentorEmail?: string;
  open: boolean;
  onToggle: () => void;
  onStatus: (v: ReqStatus) => void;
  onSaved: () => void;
}) {

  const { t, locale } = useI18n();
  const scheduled = b.scheduled_at ? new Date(b.scheduled_at) : null;
  const [date, setDate] = useState(scheduled ? scheduled.toISOString().slice(0, 10) : "");
  const [time, setTime] = useState(scheduled ? scheduled.toISOString().slice(11, 16) : "");
  const [tz, setTz] = useState(b.scheduled_timezone || "Asia/Bishkek");
  const [dur, setDur] = useState<number>(b.duration_min ?? 60);
  const [saving, setSaving] = useState(false);
  const status: ReqStatus = b.request_status ?? "new";
  const showPlanning = status === "scheduled" || status === "confirmed" || status === "completed";

  async function savePlan() {
    if (!date || !time) { toast.error(t("admin.b.planRequired")); return; }
    setSaving(true);
    const utc = zonedToUtc(date, time, tz);
    const { error } = await supabase
      .from("bookings")
      .update({
        scheduled_at: utc.toISOString(),
        scheduled_timezone: tz,
        duration_min: dur,
        starts_at: utc.toISOString(),
        ends_at: new Date(utc.getTime() + dur * 60000).toISOString(),
      })
      .eq("id", b.id);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    onSaved();
    toast.success(t("admin.saved"));
  }

  const mentorName = b.mentors?.full_name ?? "Mentor";
  const mentorMail = (mentorEmail ?? "").trim();
  const gcal = calendarUrl(
    { ...b, scheduled_at: date && time ? zonedToUtc(date, time, tz).toISOString() : b.scheduled_at, scheduled_timezone: tz, duration_min: dur },
    mentorName,
    [b.client_note, b.contact_phone, b.meet_url].filter(Boolean).join(" · "),
    mentorMail,
  );


  return (
    <div className="rounded-2xl border border-border">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="block w-full p-4 text-left text-sm"
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="font-semibold">{b.contact_name || "—"}</div>
            <div className="text-muted-foreground">
              {t("admin.b.mentor")}: {mentorName}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{t(`reqstatus.${status}`)}</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} />
          </div>
        </div>
        <div className="mt-3 grid gap-1 text-xs text-muted-foreground sm:grid-cols-2 lg:grid-cols-4">
          <span>{(b.duration_min ?? 60) === 30 ? t("book.min30") : t("book.min60")}</span>
          <span className="font-semibold text-foreground">{formatPrice(b.amount, b.currency, locale)}</span>
          <span>{t("admin.b.created")}: {formatDateTime(b.created_at, locale)}</span>
          <span className="truncate">
            {b.contact_phone || b.contact_email || "—"}
            {b.contact_method ? ` · ${t(`book.method.${b.contact_method}`)}` : ""}
          </span>
        </div>
      </button>

      <div
        className={`grid overflow-hidden transition-all duration-300 ${open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
      >
        <div className="min-h-0">
          <div className="space-y-5 border-t border-border p-4 text-sm">
            <div>
              <div className="text-xs uppercase tracking-wide text-muted-foreground">{t("book.reqStatus")}</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {REQ_STATUSES.map((rs) => (
                  <button
                    key={rs}
                    type="button"
                    onClick={() => onStatus(rs)}
                    className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
                      status === rs
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {t(`reqstatus.${rs}`)}
                  </button>
                ))}
              </div>
            </div>

            <dl className="grid gap-3 sm:grid-cols-2">
              <Row label={t("admin.b.client")} value={b.contact_name} />
              <Row label="Email" value={b.contact_email} onCopy={b.contact_email ? () => copy(b.contact_email!, t("admin.b.copied")) : undefined} />
              <Row label={t("book.phone")} value={b.contact_phone} onCopy={b.contact_phone ? () => copy(b.contact_phone!, t("admin.b.copied")) : undefined} />
              <Row label={t("book.method")} value={b.contact_method ? t(`book.method.${b.contact_method}`) : ""} />
              <Row label={t("book.preferred")} value={b.preferred_time} />
              <Row label={t("admin.b.mentor")} value={mentorName} />
              <Row
                label={t("admin.b.mentorEmail")}
                value={mentorMail}
                onCopy={mentorMail ? () => copy(mentorMail, t("admin.b.copied")) : undefined}
              />

              <Row label={t("book.duration")} value={(b.duration_min ?? 60) === 30 ? t("book.min30") : t("book.min60")} />
              <Row label={t("admin.price")} value={formatPrice(b.amount, b.currency, locale)} />
              <Row label={t("admin.b.session")} value={b.scheduled_at ? formatDateTime(b.scheduled_at, locale) : formatDateTime(b.starts_at, locale)} />
              <Row label={t("admin.b.created")} value={formatDateTime(b.created_at, locale)} />
            </dl>

            <div>
              <div className="text-xs uppercase tracking-wide text-muted-foreground">{t("book.note")}</div>
              <p className="mt-1 whitespace-pre-wrap break-words rounded-xl border border-border p-3">
                {b.client_note || b.topic || "—"}
              </p>
            </div>

            {showPlanning && (
              <div className="rounded-2xl border border-border bg-secondary/40 p-4">
                <h3 className="font-display text-base">{t("admin.b.planning")}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{t("admin.b.planNotice")}</p>
                <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <label className="grid gap-1 text-xs">
                    {t("admin.b.date")}
                    <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-10 rounded-xl border border-border bg-card px-3 text-sm" />
                  </label>
                  <label className="grid gap-1 text-xs">
                    {t("admin.b.time")}
                    <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="h-10 rounded-xl border border-border bg-card px-3 text-sm" />
                  </label>
                  <label className="grid gap-1 text-xs">
                    {t("admin.b.tz")}
                    <NativeSelect value={tz} onChange={(e) => setTz(e.target.value)} className="rounded-xl bg-card">
                      {TIMEZONES.map((z) => <option key={z} value={z}>{z}</option>)}
                    </NativeSelect>
                  </label>
                  <label className="grid gap-1 text-xs">
                    {t("book.duration")}
                    <NativeSelect value={dur} onChange={(e) => setDur(Number(e.target.value))} className="rounded-xl bg-card">
                      <option value={30}>{t("book.min30")}</option>
                      <option value={60}>{t("book.min60")}</option>
                    </NativeSelect>
                  </label>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button size="sm" onClick={savePlan} disabled={saving}>{t("admin.save")}</Button>
                  <Button size="sm" variant="outline" asChild>
                    <a href={gcal} target="_blank" rel="noreferrer">
                      <CalendarPlus className="mr-2 h-4 w-4" />
                      {t("admin.b.gcal")}
                    </a>
                  </Button>
                </div>
                {!mentorMail && (
                  <p className="mt-3 rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
                    {t("admin.b.noMentorEmail")}
                  </p>
                )}

                <p className="mt-3 text-xs text-muted-foreground">{t("admin.b.futureIntegration")}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
