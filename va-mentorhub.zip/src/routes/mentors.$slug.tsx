import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Globe, MapPin, Star, Video } from "lucide-react";
import { toast } from "sonner";
import { Shell } from "@/components/site-chrome";
import { Avatar } from "@/components/brand";
import { Reveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PhoneInput } from "@/components/phone-input";
import { supabase } from "@/integrations/supabase/client";

import { useI18n } from "@/lib/i18n";
import { useSession } from "@/lib/session";
import { useCurrency } from "@/lib/currency";
import { NativeSelect } from "@/components/native-select";
import {
  COUNTRY_LABEL,
  LANG_LABEL,
  localized,
  mentorJobTitle,
  mentorName,
  mentorSectors,
  type Mentor,

} from "@/lib/mentorhub";

export const Route = createFileRoute("/mentors/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `Эксперт ${params.slug} — VirtualAccelerate MentorHub` },
      { name: "description", content: "Профиль эксперта: опыт, отзывы и бронирование сессии." },
      { property: "og:title", content: "Профиль эксперта — MentorHub" },
      { property: "og:description", content: "Забронируйте сессию 1:1 с экспертом." },
    ],
  }),
  component: MentorProfile,
});

function MentorProfile() {
  const { slug } = Route.useParams();
  const { t, locale } = useI18n();
  const { display } = useCurrency();
  const { user } = useSession();
  const navigate = useNavigate();

  const [busy, setBusy] = useState(false);
  const [duration, setDuration] = useState<30 | 60>(60);
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [contactMethod, setContactMethod] = useState("whatsapp");
  const [preferredTime, setPreferredTime] = useState("");
  const [note, setNote] = useState("");

  const qc = useQueryClient();

  const mentorQ = useQuery({
    queryKey: ["mentor", slug],
    queryFn: async () => {
      const { data, error } = await supabase.from("mentors").select("*").eq("slug", slug).maybeSingle();
      if (error) throw error;
      return data as unknown as Mentor | null;
    },
    // Show the mentor immediately if the catalog already fetched them.
    placeholderData: () =>
      (qc.getQueryData(["mentors"]) as Mentor[] | undefined)?.find((m) => m.slug === slug) ?? undefined,
  });

  const mentor = mentorQ.data;

  const reviewsQ = useQuery({
    queryKey: ["reviews", mentor?.id],
    enabled: !!mentor?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reviews")
        .select("*")
        .eq("mentor_id", mentor!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  if (mentorQ.isLoading) {
    return (
      <Shell>
        <div className="mx-auto max-w-6xl px-4 py-24 text-muted-foreground">{t("loading")}</div>
      </Shell>
    );
  }

  if (!mentor) {
    return (
      <Shell>
        <div className="mx-auto max-w-6xl px-4 py-24 text-center">
          <h1 className="font-display text-2xl">{t("mentor.notFound")}</h1>
          <Button asChild className="mt-6">
            <Link to="/mentors">{t("featured.all")}</Link>
          </Button>
        </div>
      </Shell>
    );
  }

  const basePrice = mentor
    ? duration === 30
      ? mentor.price_30 || Math.round((mentor.price_60 || mentor.price_per_hour) / 2)
      : mentor.price_60 || mentor.price_per_hour
    : 0;

  async function book() {
    if (!user) {
      toast.error(t("mentor.needAuth"));
      await navigate({ to: "/auth" });
      return;
    }
    if (!mentor) return;
    if (!contactName.trim() || !contactPhone.trim()) {
      toast.error(t("book.required"));
      return;
    }

    const startsAt = new Date().toISOString();
    const endsAt = new Date(Date.now() + duration * 60 * 1000).toISOString();

    setBusy(true);
    const { data, error } = await supabase
      .from("bookings")
      .insert({
        mentor_id: mentor.id,
        client_id: user.id,
        starts_at: startsAt,
        ends_at: endsAt,
        amount: basePrice,
        currency: mentor.currency,
        duration_min: duration,
        contact_name: contactName.trim().slice(0, 100),
        contact_email: (user.email ?? "").slice(0, 255),
        contact_phone: contactPhone.trim().slice(0, 40),
        contact_method: contactMethod,
        preferred_time: preferredTime.trim().slice(0, 200),
        client_note: note.trim().slice(0, 1000),
      })
      .select("id")
      .single();
    setBusy(false);

    if (error || !data) {
      toast.error(error?.message ?? t("error"));
      return;
    }
    toast.success(t("book.sent"));
    await navigate({ to: "/dashboard" });
  }

  const row = mentor as unknown as Record<string, unknown>;

  return (
    <Shell>
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 lg:grid-cols-[1.6fr_1fr]">
        <div>
          <Reveal>
            <div className="rounded-3xl border border-border bg-card p-6 sm:p-8">
              <div className="flex flex-wrap items-start gap-5">
                <Avatar name={mentorName(mentor, locale)} size={88} src={mentor.avatar_url} />
                <div className="min-w-0 flex-1">
                  <h1 className="font-display text-2xl sm:text-3xl">{mentorName(mentor, locale)}</h1>
                  {mentorJobTitle(mentor, locale) ? (
                    <p className="mt-1 font-medium text-primary">{mentorJobTitle(mentor, locale)}</p>
                  ) : null}
                  {localized(row, "headline", locale) &&
                  localized(row, "headline", locale) !== mentorJobTitle(mentor, locale) ? (
                    <p className="mt-2 text-muted-foreground">{localized(row, "headline", locale)}</p>
                  ) : null}
                  <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <Star className="h-4 w-4 fill-primary text-primary" />
                      <b className="text-foreground">{mentor.rating.toFixed(1)}</b> · {mentor.reviews_count}{" "}
                      {t("mentor.reviews")}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-4 w-4" />
                      {mentor.city ? `${mentor.city}, ` : ""}
                      {COUNTRY_LABEL[mentor.country]?.[locale] ?? mentor.country}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Globe className="h-4 w-4" />
                      {mentor.languages.map((l) => LANG_LABEL[l]?.[locale] ?? l).join(", ")}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Video className="h-4 w-4" />
                      {mentor.sessions_count} {t("mentor.sessions")}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={80}>
            <section className="mt-6 rounded-3xl border border-border bg-card p-6 sm:p-8">
              <h2 className="font-display text-xl">{t("mentor.about")}</h2>
              <p className="mt-3 whitespace-pre-line leading-relaxed text-muted-foreground">
                {localized(row, "bio", locale)}
              </p>
              <h3 className="mt-8 font-display text-base">{t("mentor.expertise")}</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {mentorSectors(mentor, locale).map((e) => (
                  <span key={e} className="rounded-full bg-secondary px-3 py-1.5 text-sm">
                    {e}
                  </span>
                ))}
              </div>
            </section>
          </Reveal>

          <Reveal delay={140}>
            <section className="mt-6 rounded-3xl border border-border bg-card p-6 sm:p-8">
              <h2 className="font-display text-xl">{t("mentor.reviewsTitle")}</h2>
              <div className="mt-5 space-y-4">
                {(reviewsQ.data ?? []).map((r) => (
                  <div key={r.id} className="rounded-2xl border border-border p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{r.author_name}</span>
                      <span className="flex items-center gap-1 text-sm">
                        <Star className="h-3.5 w-3.5 fill-primary text-primary" />
                        {r.rating}
                      </span>
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{r.comment}</p>
                  </div>
                ))}
                {!reviewsQ.data?.length && <p className="text-sm text-muted-foreground">—</p>}
              </div>
            </section>
          </Reveal>
        </div>

        {/* Booking panel */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <Reveal delay={60}>
            <div className="rounded-3xl border border-border bg-card p-6 shadow-glow">
              <div className="flex items-baseline gap-2">
                <span className="font-display text-3xl font-bold text-gradient-brand">
                  {display(basePrice, mentor.currency, locale)}
                </span>
                <span className="text-sm text-muted-foreground">
                  / {duration === 30 ? t("book.min30") : t("book.min60")}
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">{t("cur.note")}</p>

              <label className="mt-6 block text-sm font-medium">{t("book.duration")}</label>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {([30, 60] as const).map((d) => {
                  const price =
                    d === 30
                      ? mentor.price_30 || Math.round((mentor.price_60 || mentor.price_per_hour) / 2)
                      : mentor.price_60 || mentor.price_per_hour;
                  return (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDuration(d)}
                      className={`rounded-xl border px-3 py-2.5 text-sm transition-all duration-200 ${
                        duration === d
                          ? "border-transparent bg-gradient-brand text-primary-foreground"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <div className="font-semibold">{d === 30 ? t("book.min30") : t("book.min60")}</div>
                      <div className="text-xs opacity-90">{display(price, mentor.currency, locale)}</div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-6 border-t border-border pt-5">
                <h3 className="font-display text-base">{t("book.requestTitle")}</h3>

                <label className="mt-4 block text-sm font-medium">{t("book.name")}</label>
                <Input
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  maxLength={100}
                  className="mt-2"
                />

                <label className="mt-4 block text-sm font-medium">{t("book.phone")}</label>
                <PhoneInput value={contactPhone} onChange={setContactPhone} className="mt-2" />


                <label className="mt-4 block text-sm font-medium">{t("book.method")}</label>
                <NativeSelect
                  value={contactMethod}
                  onChange={(e) => setContactMethod(e.target.value)}
                  wrapperClassName="mt-2"
                >
                  {["whatsapp", "telegram", "call", "email"].map((m) => (
                    <option key={m} value={m}>
                      {t(`book.method.${m}`)}
                    </option>
                  ))}
                </NativeSelect>

                {user?.email ? (
                  <p className="mt-3 text-xs text-muted-foreground">Email: {user.email}</p>
                ) : null}

                <label className="mt-4 block text-sm font-medium">{t("book.preferred")}</label>
                <Input
                  value={preferredTime}
                  onChange={(e) => setPreferredTime(e.target.value)}
                  placeholder={t("book.preferredPh")}
                  maxLength={200}
                  className="mt-2"
                />

                <label className="mt-4 block text-sm font-medium">{t("book.note")}</label>
                <Textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder={t("book.notePh")}
                  maxLength={1000}
                  rows={3}
                  className="mt-2"
                />
              </div>

              <Button
                onClick={book}
                disabled={busy}
                size="lg"
                className="mt-6 w-full bg-gradient-brand text-primary-foreground"
              >
                {t("book.send")}
              </Button>
              <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{t("book.contactNote")}</p>
            </div>
          </Reveal>
        </aside>
      </div>
    </Shell>
  );
}
