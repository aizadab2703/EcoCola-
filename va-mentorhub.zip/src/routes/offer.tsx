import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/site-chrome";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/offer")({
  head: () => ({
    meta: [
      { title: "Публичная оферта — VirtualAccelerate MentorHub" },
      { name: "description", content: "Условия оказания услуг платформы MentorHub: оплата, отмена, возврат, ответственность." },
      { property: "og:title", content: "Публичная оферта — MentorHub" },
      { property: "og:description", content: "Условия оказания экспертных услуг на платформе." },
    ],
  }),
  component: Offer,
});

const RU = [
  ["1. Общие положения", "Настоящий документ является публичной офертой ОсОО «VirtualAccelerate» (далее — Платформа) и определяет условия использования сервиса MentorHub — маркетплейса платных экспертных консультаций. Акцептом оферты считается регистрация на Платформе или оплата сессии."],
  ["2. Предмет", "Платформа предоставляет технологический сервис: каталог экспертов, бронирование слотов, проведение оплаты и организацию видеовстречи. Консультационные услуги оказывает эксперт лично; Платформа не является стороной консультации."],
  ["3. Стоимость и оплата", "Стоимость часа устанавливает эксперт и отображается в его профиле. Оплата производится через платёжного провайдера Finik. В демонстрационном режиме Платформы реальное списание средств не производится — оплата имитируется для целей тестирования."],
  ["4. Отмена и возврат", "Клиент вправе отменить сессию не позднее чем за 24 часа до её начала с полным возвратом средств. При отмене менее чем за 24 часа средства не возвращаются, за исключением случаев отмены по инициативе эксперта."],
  ["5. Проведение сессии", "Сессия проводится онлайн. Ссылка на встречу Google Meet и событие в Google Calendar формируются автоматически после подтверждения оплаты и доступны в личном кабинете обеих сторон."],
  ["6. Ответственность", "Платформа не гарантирует достижение клиентом конкретных бизнес-результатов. Мнения и рекомендации эксперта не являются юридической, налоговой или инвестиционной консультацией."],
  ["7. Персональные данные", "Платформа обрабатывает персональные данные в объёме, необходимом для оказания услуг, и не передаёт их третьим лицам, кроме платёжного провайдера и сервисов видеосвязи."],
  ["8. Контакты", "По любым вопросам: hello@virtualaccelerate.org"],
];

const EN = [
  ["1. General", "This document is a public offer by VirtualAccelerate LLC (the Platform) and sets out the terms of use of MentorHub — a marketplace for paid 1:1 expert consultations. Registration on the Platform or payment for a session constitutes acceptance."],
  ["2. Subject", "The Platform provides a technology service: an expert catalog, slot booking, payment processing and video-call setup. Advisory services are delivered by the expert personally; the Platform is not a party to the consultation."],
  ["3. Price and payment", "The hourly rate is set by the expert and shown in their profile. Payments are processed via the Finik payment provider. While the Platform runs in demo mode no funds are actually charged — payment is simulated for testing."],
  ["4. Cancellation and refunds", "A client may cancel no later than 24 hours before the session start for a full refund. Cancellations made less than 24 hours in advance are non-refundable, unless cancelled by the expert."],
  ["5. Session delivery", "Sessions run online. A Google Meet link and a Google Calendar event are created automatically after payment confirmation and are available in both parties' dashboards."],
  ["6. Liability", "The Platform does not guarantee any specific business outcome. Expert opinions are not legal, tax or investment advice."],
  ["7. Personal data", "The Platform processes personal data only as needed to deliver the service and does not share it with third parties other than the payment provider and video-conferencing services."],
  ["8. Contact", "Any questions: hello@virtualaccelerate.org"],
];

function Offer() {
  const { locale, t } = useI18n();
  const items = locale === "ru" ? RU : EN;
  return (
    <Shell>
      <div className="mx-auto max-w-3xl px-4 py-16">
        <h1 className="font-display text-3xl sm:text-4xl">{t("offer.title")}</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          {locale === "ru" ? "Редакция от" : "Version of"} {new Date().getFullYear()}
        </p>
        <div className="mt-10 space-y-8">
          {items.map(([title, body]) => (
            <section key={title}>
              <h2 className="font-display text-lg font-semibold">{title}</h2>
              <p className="mt-2 leading-relaxed text-muted-foreground">{body}</p>
            </section>
          ))}
        </div>
      </div>
    </Shell>
  );
}
