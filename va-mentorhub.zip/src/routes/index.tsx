import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, CalendarCheck, CreditCard, Search } from "lucide-react";
import { Shell } from "@/components/site-chrome";
import { CounterUp, MentorOrbit, Reveal, Typewriter } from "@/components/motion";
import { MentorCard } from "@/components/mentor-card";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { fetchCategories, fetchMentors } from "@/lib/mentorhub";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VirtualAccelerate MentorHub — платные эксперты Центральной Азии" },
      {
        name: "description",
        content:
          "Забронируйте сессию 1:1 с практиками из Кыргызстана, Казахстана и Узбекистана: стартапы, продукт, инженерия, маркетинг, финансы, AI.",
      },
      { property: "og:title", content: "VirtualAccelerate MentorHub" },
      {
        property: "og:description",
        content: "Маркетплейс платных экспертных консультаций для Центральной Азии. Выбирайте, бронируйте, растите.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { t, locale } = useI18n();
  const mentors = useQuery({ queryKey: ["mentors"], queryFn: fetchMentors });
  const categories = useQuery({ queryKey: ["categories"], queryFn: fetchCategories });

  const words =
    locale === "ru"
      ? ["стартапам", "продукту", "инженерии", "маркетингу", "финансам", "AI и данным", "автоматизации", "налогам", "зелёному бизнесу и ESG"]
      : ["startups", "product", "engineering", "marketing", "finance", "AI & data", "automation", "taxes", "green business & ESG"];

  const list = mentors.data ?? [];

  return (
    <Shell>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0">
          <div className="aurora -left-20 top-0 h-72 w-72 bg-primary/40" />
          <div className="aurora right-0 top-32 h-80 w-80 bg-brand-blue/35" style={{ animationDelay: "-8s" }} />
        </div>

        <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-4 py-16 md:py-24 lg:grid-cols-[1.15fr_1fr]">
          <div>
            <Reveal delay={80}>
              <h1 className="font-display text-4xl leading-[1.06] sm:text-5xl lg:text-6xl">
                {t("hero.staticStart")}
                <br />
                <Typewriter words={words} />
              </h1>
            </Reveal>

            <Reveal delay={160}>
              <p className="mt-6 max-w-xl whitespace-pre-line text-base leading-relaxed text-muted-foreground">{t("hero.sub")}</p>
            </Reveal>

            <Reveal delay={240}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Button asChild size="lg" className="bg-gradient-brand text-primary-foreground shadow-glow">
                  <Link to="/mentors">
                    {t("hero.cta")} <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link to="/become-a-mentor">{t("hero.cta2")}</Link>
                </Button>
              </div>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <MentorOrbit names={list.length ? list.map((m) => m.full_name) : ["A B", "C D", "E F", "G H", "I J", "K L"]} />
          </Reveal>
        </div>
      </section>

      {/* STATS */}
      <section className="border-y border-border bg-card">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-12 md:grid-cols-4">
          {[
            { value: <CounterUp to={150} suffix="+" />, label: t("stats.mentors") },
            { value: <CounterUp to={1200} suffix="+" />, label: t("stats.sessions") },
            { value: <CounterUp to={4.9} decimals={1} />, label: t("stats.rating") },
            { value: <CounterUp to={3} />, label: t("stats.countries") },
          ].map((s, i) => (
            <Reveal key={i} delay={i * 90}>
              <div>
                <div className="font-display text-4xl font-bold text-gradient-brand">{s.value}</div>
                <div className="mt-2 text-sm text-muted-foreground">{s.label}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* HOW */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <Reveal>
          <h2 className="font-display text-3xl sm:text-4xl">{t("how.title")}</h2>
        </Reveal>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {[
            { icon: Search, t: t("how.1.t"), d: t("how.1.d") },
            { icon: CalendarCheck, t: t("how.2.t"), d: t("how.2.d") },
            { icon: CreditCard, t: t("how.3.t"), d: t("how.3.d") },
          ].map((s, i) => (
            <Reveal key={i} delay={i * 100}>
              <div className="lift-hover h-full rounded-2xl border border-border bg-card p-6">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-brand text-primary-foreground">
                  <s.icon className="h-5 w-5" />
                </div>
                <div className="mt-5 font-display text-lg font-semibold">
                  <span className="mr-2 text-primary">0{i + 1}</span>
                  {s.t}
                </div>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="border-y border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-20">
          <Reveal>
            <h2 className="font-display text-3xl sm:text-4xl">{t("cats.title")}</h2>
            <p className="mt-3 max-w-xl text-muted-foreground">{t("cats.sub")}</p>
          </Reveal>
          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {(categories.data ?? []).map((c, i) => (
              <Reveal key={c.slug} delay={i * 60}>
                <Link
                  to="/mentors"
                  search={{ category: c.slug }}
                  className="lift-hover flex h-full items-center justify-between gap-3 rounded-2xl border border-border bg-background p-4"
                >
                  <span className="font-medium">{locale === "ru" ? c.name_ru : c.name_en}</span>
                  <ArrowRight className="h-4 w-4 shrink-0 text-primary transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED */}
      <section className="mx-auto max-w-6xl px-4 py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <Reveal>
            <h2 className="font-display text-3xl sm:text-4xl">{t("featured.title")}</h2>
          </Reveal>
          <Button asChild variant="ghost">
            <Link to="/mentors">
              {t("featured.all")} <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.slice(0, 6).map((m, i) => (
            <Reveal key={m.id} delay={i * 70}>
              <MentorCard mentor={m} />
            </Reveal>
          ))}
        </div>
      </section>
    </Shell>
  );
}
