export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.17"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          amount: number
          calendar_event_id: string | null
          client_id: string
          client_note: string
          contact_email: string
          contact_method: string
          contact_name: string
          contact_phone: string
          created_at: string
          currency: string
          duration_min: number
          ends_at: string
          id: string
          meet_url: string | null
          mentor_id: string
          preferred_time: string
          request_status: Database["public"]["Enums"]["booking_request_status"]
          scheduled_at: string | null
          scheduled_timezone: string
          slot_id: string | null
          starts_at: string
          status: Database["public"]["Enums"]["booking_status"]
          topic: string
        }
        Insert: {
          amount?: number
          calendar_event_id?: string | null
          client_id: string
          client_note?: string
          contact_email?: string
          contact_method?: string
          contact_name?: string
          contact_phone?: string
          created_at?: string
          currency?: string
          duration_min?: number
          ends_at: string
          id?: string
          meet_url?: string | null
          mentor_id: string
          preferred_time?: string
          request_status?: Database["public"]["Enums"]["booking_request_status"]
          scheduled_at?: string | null
          scheduled_timezone?: string
          slot_id?: string | null
          starts_at: string
          status?: Database["public"]["Enums"]["booking_status"]
          topic?: string
        }
        Update: {
          amount?: number
          calendar_event_id?: string | null
          client_id?: string
          client_note?: string
          contact_email?: string
          contact_method?: string
          contact_name?: string
          contact_phone?: string
          created_at?: string
          currency?: string
          duration_min?: number
          ends_at?: string
          id?: string
          meet_url?: string | null
          mentor_id?: string
          preferred_time?: string
          request_status?: Database["public"]["Enums"]["booking_request_status"]
          scheduled_at?: string | null
          scheduled_timezone?: string
          slot_id?: string | null
          starts_at?: string
          status?: Database["public"]["Enums"]["booking_status"]
          topic?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "mentors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_slot_id_fkey"
            columns: ["slot_id"]
            isOneToOne: false
            referencedRelation: "mentor_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          icon: string | null
          id: string
          name_en: string
          name_ru: string
          slug: string
          sort_order: number
        }
        Insert: {
          icon?: string | null
          id?: string
          name_en: string
          name_ru: string
          slug: string
          sort_order?: number
        }
        Update: {
          icon?: string | null
          id?: string
          name_en?: string
          name_ru?: string
          slug?: string
          sort_order?: number
        }
        Relationships: []
      }
      invitations: {
        Row: {
          accepted_at: string | null
          created_at: string
          email: string
          id: string
          invited_by: string | null
          role: Database["public"]["Enums"]["app_role"]
          status: Database["public"]["Enums"]["invitation_status"]
          token: string
        }
        Insert: {
          accepted_at?: string | null
          created_at?: string
          email: string
          id?: string
          invited_by?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          status?: Database["public"]["Enums"]["invitation_status"]
          token?: string
        }
        Update: {
          accepted_at?: string | null
          created_at?: string
          email?: string
          id?: string
          invited_by?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          status?: Database["public"]["Enums"]["invitation_status"]
          token?: string
        }
        Relationships: []
      }
      mentor_applications: {
        Row: {
          about: string
          admin_note: string
          avatar_url: string | null
          country: string
          created_at: string
          currency: string
          email: string
          full_name: string
          id: string
          job_title: string
          linkedin_url: string | null
          phone: string
          price_30: number
          price_60: number
          sectors: string[]
          short_bio: string
          status: Database["public"]["Enums"]["application_status"]
          updated_at: string
        }
        Insert: {
          about?: string
          admin_note?: string
          avatar_url?: string | null
          country?: string
          created_at?: string
          currency?: string
          email: string
          full_name: string
          id?: string
          job_title?: string
          linkedin_url?: string | null
          phone?: string
          price_30?: number
          price_60?: number
          sectors?: string[]
          short_bio?: string
          status?: Database["public"]["Enums"]["application_status"]
          updated_at?: string
        }
        Update: {
          about?: string
          admin_note?: string
          avatar_url?: string | null
          country?: string
          created_at?: string
          currency?: string
          email?: string
          full_name?: string
          id?: string
          job_title?: string
          linkedin_url?: string | null
          phone?: string
          price_30?: number
          price_60?: number
          sectors?: string[]
          short_bio?: string
          status?: Database["public"]["Enums"]["application_status"]
          updated_at?: string
        }
        Relationships: []
      }
      mentor_slots: {
        Row: {
          created_at: string
          ends_at: string
          id: string
          is_booked: boolean
          mentor_id: string
          starts_at: string
        }
        Insert: {
          created_at?: string
          ends_at: string
          id?: string
          is_booked?: boolean
          mentor_id: string
          starts_at: string
        }
        Update: {
          created_at?: string
          ends_at?: string
          id?: string
          is_booked?: boolean
          mentor_id?: string
          starts_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "mentor_slots_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "mentors"
            referencedColumns: ["id"]
          },
        ]
      }
      mentors: {
        Row: {
          avatar_url: string | null
          bio_en: string
          bio_ru: string
          category_slug: string
          city: string | null
          country: string
          created_at: string
          currency: string
          email: string | null
          en_source_hash: string | null
          expertise: string[]
          expertise_en: string[] | null
          full_name: string
          full_name_en: string | null
          headline_en: string
          headline_ru: string
          id: string
          is_published: boolean
          job_title: string
          job_title_en: string | null
          languages: string[]
          linkedin_url: string | null
          price_30: number
          price_60: number
          price_per_hour: number
          rating: number
          reviews_count: number
          sessions_count: number
          short_bio_en: string
          short_bio_ru: string
          slug: string
          status: Database["public"]["Enums"]["mentor_status"]
          user_id: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio_en?: string
          bio_ru?: string
          category_slug: string
          city?: string | null
          country?: string
          created_at?: string
          currency?: string
          email?: string | null
          en_source_hash?: string | null
          expertise?: string[]
          expertise_en?: string[] | null
          full_name: string
          full_name_en?: string | null
          headline_en?: string
          headline_ru?: string
          id?: string
          is_published?: boolean
          job_title?: string
          job_title_en?: string | null
          languages?: string[]
          linkedin_url?: string | null
          price_30?: number
          price_60?: number
          price_per_hour?: number
          rating?: number
          reviews_count?: number
          sessions_count?: number
          short_bio_en?: string
          short_bio_ru?: string
          slug: string
          status?: Database["public"]["Enums"]["mentor_status"]
          user_id?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio_en?: string
          bio_ru?: string
          category_slug?: string
          city?: string | null
          country?: string
          created_at?: string
          currency?: string
          email?: string | null
          en_source_hash?: string | null
          expertise?: string[]
          expertise_en?: string[] | null
          full_name?: string
          full_name_en?: string | null
          headline_en?: string
          headline_ru?: string
          id?: string
          is_published?: boolean
          job_title?: string
          job_title_en?: string | null
          languages?: string[]
          linkedin_url?: string | null
          price_30?: number
          price_60?: number
          price_per_hour?: number
          rating?: number
          reviews_count?: number
          sessions_count?: number
          short_bio_en?: string
          short_bio_ru?: string
          slug?: string
          status?: Database["public"]["Enums"]["mentor_status"]
          user_id?: string | null
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          booking_id: string
          created_at: string
          currency: string
          external_id: string | null
          id: string
          provider: string
          status: Database["public"]["Enums"]["payment_status"]
        }
        Insert: {
          amount?: number
          booking_id: string
          created_at?: string
          currency?: string
          external_id?: string | null
          id?: string
          provider?: string
          status?: Database["public"]["Enums"]["payment_status"]
        }
        Update: {
          amount?: number
          booking_id?: string
          created_at?: string
          currency?: string
          external_id?: string | null
          id?: string
          provider?: string
          status?: Database["public"]["Enums"]["payment_status"]
        }
        Relationships: [
          {
            foreignKeyName: "payments_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          locale: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          locale?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          locale?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          author_name: string
          booking_id: string | null
          client_id: string
          comment: string
          created_at: string
          id: string
          mentor_id: string
          rating: number
        }
        Insert: {
          author_name?: string
          booking_id?: string | null
          client_id: string
          comment?: string
          created_at?: string
          id?: string
          mentor_id: string
          rating?: number
        }
        Update: {
          author_name?: string
          booking_id?: string | null
          client_id?: string
          comment?: string
          created_at?: string
          id?: string
          mentor_id?: string
          rating?: number
        }
        Relationships: [
          {
            foreignKeyName: "reviews_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "mentors"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "mentor" | "client"
      application_status: "new" | "approved" | "rejected"
      booking_request_status:
        | "new"
        | "contacted"
        | "scheduled"
        | "declined"
        | "confirmed"
        | "completed"
        | "cancelled"
      booking_status:
        | "pending_payment"
        | "confirmed"
        | "completed"
        | "cancelled"
      invitation_status: "pending" | "accepted" | "revoked"
      mentor_status: "pending" | "active" | "paused"
      payment_status: "demo_pending" | "demo_paid" | "failed" | "refunded"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "mentor", "client"],
      application_status: ["new", "approved", "rejected"],
      booking_request_status: [
        "new",
        "contacted",
        "scheduled",
        "declined",
        "confirmed",
        "completed",
        "cancelled",
      ],
      booking_status: [
        "pending_payment",
        "confirmed",
        "completed",
        "cancelled",
      ],
      invitation_status: ["pending", "accepted", "revoked"],
      mentor_status: ["pending", "active", "paused"],
      payment_status: ["demo_pending", "demo_paid", "failed", "refunded"],
    },
  },
} as const
