REVOKE ALL ON FUNCTION public.grant_admin_for_bootstrap_email() FROM public, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM public, anon, authenticated;