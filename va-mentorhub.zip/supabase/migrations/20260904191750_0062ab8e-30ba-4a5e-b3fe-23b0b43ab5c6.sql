ALTER TYPE public.booking_request_status ADD VALUE IF NOT EXISTS 'confirmed';
ALTER TYPE public.booking_request_status ADD VALUE IF NOT EXISTS 'completed';
ALTER TYPE public.booking_request_status ADD VALUE IF NOT EXISTS 'cancelled';

ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS scheduled_at timestamptz;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS scheduled_timezone text NOT NULL DEFAULT 'Asia/Bishkek';