CREATE TYPE public.booking_request_status AS ENUM ('new','contacted','scheduled','declined');

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS duration_min integer NOT NULL DEFAULT 60,
  ADD COLUMN IF NOT EXISTS contact_name text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS contact_email text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS contact_phone text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS contact_method text NOT NULL DEFAULT 'whatsapp',
  ADD COLUMN IF NOT EXISTS preferred_time text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS client_note text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS request_status public.booking_request_status NOT NULL DEFAULT 'new';

ALTER TABLE public.bookings
  ADD CONSTRAINT bookings_duration_min_chk CHECK (duration_min IN (30, 60));