ALTER TABLE public.mentors
  ADD COLUMN IF NOT EXISTS job_title_en text,
  ADD COLUMN IF NOT EXISTS expertise_en text[],
  ADD COLUMN IF NOT EXISTS en_source_hash text;