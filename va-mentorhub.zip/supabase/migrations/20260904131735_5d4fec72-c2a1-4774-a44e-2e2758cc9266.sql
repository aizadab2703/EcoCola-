-- enums
CREATE TYPE public.app_role AS ENUM ('admin','mentor','client');
CREATE TYPE public.booking_status AS ENUM ('pending_payment','confirmed','completed','cancelled');
CREATE TYPE public.payment_status AS ENUM ('demo_pending','demo_paid','failed','refunded');
CREATE TYPE public.invitation_status AS ENUM ('pending','accepted','revoked');

-- profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  full_name text,
  email text,
  avatar_url text,
  locale text NOT NULL DEFAULT 'ru',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- roles
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE POLICY "roles_select_own" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- auto profile + default client role
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, avatar_url)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.email, NEW.raw_user_meta_data->>'avatar_url')
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client')
  ON CONFLICT (user_id, role) DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- categories
CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name_ru text NOT NULL,
  name_en text NOT NULL,
  icon text,
  sort_order int NOT NULL DEFAULT 0
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories_public_read" ON public.categories FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "categories_admin_write" ON public.categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- mentors
CREATE TABLE public.mentors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  slug text NOT NULL UNIQUE,
  full_name text NOT NULL,
  headline_ru text NOT NULL DEFAULT '',
  headline_en text NOT NULL DEFAULT '',
  bio_ru text NOT NULL DEFAULT '',
  bio_en text NOT NULL DEFAULT '',
  avatar_url text,
  country text NOT NULL DEFAULT 'KG',
  city text,
  languages text[] NOT NULL DEFAULT '{}',
  expertise text[] NOT NULL DEFAULT '{}',
  category_slug text NOT NULL,
  price_per_hour int NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'KGS',
  rating numeric(2,1) NOT NULL DEFAULT 5.0,
  reviews_count int NOT NULL DEFAULT 0,
  sessions_count int NOT NULL DEFAULT 0,
  is_published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.mentors TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mentors TO authenticated;
GRANT ALL ON public.mentors TO service_role;
ALTER TABLE public.mentors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "mentors_public_read" ON public.mentors FOR SELECT TO anon USING (is_published);
CREATE POLICY "mentors_auth_read" ON public.mentors FOR SELECT TO authenticated
  USING (is_published OR user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "mentors_owner_update" ON public.mentors FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "mentors_insert" ON public.mentors FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "mentors_admin_delete" ON public.mentors FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

-- slots
CREATE TABLE public.mentor_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_id uuid NOT NULL REFERENCES public.mentors(id) ON DELETE CASCADE,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  is_booked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX mentor_slots_mentor_idx ON public.mentor_slots(mentor_id, starts_at);
GRANT SELECT ON public.mentor_slots TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mentor_slots TO authenticated;
GRANT ALL ON public.mentor_slots TO service_role;
ALTER TABLE public.mentor_slots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "slots_public_read" ON public.mentor_slots FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "slots_owner_write" ON public.mentor_slots FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.mentors m WHERE m.id = mentor_id AND (m.user_id = auth.uid() OR public.has_role(auth.uid(),'admin'))))
  WITH CHECK (EXISTS (SELECT 1 FROM public.mentors m WHERE m.id = mentor_id AND (m.user_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));

-- bookings
CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_id uuid NOT NULL REFERENCES public.mentors(id) ON DELETE CASCADE,
  slot_id uuid REFERENCES public.mentor_slots(id) ON DELETE SET NULL,
  client_id uuid NOT NULL,
  topic text NOT NULL DEFAULT '',
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  amount int NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'KGS',
  status public.booking_status NOT NULL DEFAULT 'pending_payment',
  meet_url text,
  calendar_event_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bookings_read" ON public.bookings FOR SELECT TO authenticated
  USING (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.mentors m WHERE m.id = mentor_id AND m.user_id = auth.uid())
    OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "bookings_insert_own" ON public.bookings FOR INSERT TO authenticated
  WITH CHECK (client_id = auth.uid());
CREATE POLICY "bookings_update" ON public.bookings FOR UPDATE TO authenticated
  USING (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.mentors m WHERE m.id = mentor_id AND m.user_id = auth.uid())
    OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.mentors m WHERE m.id = mentor_id AND m.user_id = auth.uid())
    OR public.has_role(auth.uid(),'admin'));

-- payments
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'finik_demo',
  status public.payment_status NOT NULL DEFAULT 'demo_pending',
  amount int NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'KGS',
  external_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payments_read" ON public.payments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id AND (b.client_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "payments_insert" ON public.payments FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id AND b.client_id = auth.uid()));
CREATE POLICY "payments_update" ON public.payments FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id AND (b.client_id = auth.uid() OR public.has_role(auth.uid(),'admin'))))
  WITH CHECK (EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_id AND (b.client_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));

-- reviews
CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_id uuid NOT NULL REFERENCES public.mentors(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  client_id uuid NOT NULL,
  author_name text NOT NULL DEFAULT '',
  rating int NOT NULL DEFAULT 5,
  comment text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.reviews TO anon;
GRANT SELECT, INSERT ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews_public_read" ON public.reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "reviews_insert_own" ON public.reviews FOR INSERT TO authenticated
  WITH CHECK (client_id = auth.uid());

-- invitations
CREATE TABLE public.invitations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  role public.app_role NOT NULL DEFAULT 'mentor',
  token text NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(16),'hex'),
  status public.invitation_status NOT NULL DEFAULT 'pending',
  invited_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  accepted_at timestamptz
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.invitations TO authenticated;
GRANT ALL ON public.invitations TO service_role;
ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "invitations_admin_all" ON public.invitations FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- seed categories
INSERT INTO public.categories (slug, name_ru, name_en, icon, sort_order) VALUES
 ('startup','Стартапы и венчур','Startups & Venture','rocket',1),
 ('product','Продукт и UX','Product & UX','layers',2),
 ('tech','Технологии и инженерия','Tech & Engineering','code',3),
 ('marketing','Маркетинг и рост','Marketing & Growth','trending-up',4),
 ('finance','Финансы и инвестиции','Finance & Investment','banknote',5),
 ('career','Карьера и лидерство','Career & Leadership','compass',6),
 ('data','Данные и AI','Data & AI','brain',7),
 ('legal','Право и комплаенс','Legal & Compliance','scale',8);

-- seed mentors
INSERT INTO public.mentors (slug, full_name, headline_ru, headline_en, bio_ru, bio_en, country, city, languages, expertise, category_slug, price_per_hour, rating, reviews_count, sessions_count, is_published) VALUES
('aizhan-tolonova','Айжан Толонова','Основатель финтех-стартапа, экс-Kaspi','Fintech founder, ex-Kaspi','10 лет в финтехе Центральной Азии. Помогаю основателям пройти путь от идеи до первого раунда: юнит-экономика, метрики, питч инвесторам.','10 years in Central Asian fintech. I help founders go from idea to first round: unit economics, metrics, investor pitch.','KZ','Алматы','{ru,en,kk}','{"Fundraising","Unit economics","Pitch deck"}','startup',4500,4.9,37,124,true),
('daniyar-usenov','Данияр Усенов','Head of Product, маркетплейсы','Head of Product, marketplaces','Строил продукты для 3 млн пользователей в KG и UZ. Разбираю продуктовые гипотезы, дискавери и roadmap.','Built products for 3M users across KG and UZ. Product discovery, hypotheses, roadmap reviews.','KG','Бишкек','{ru,en}','{"Product discovery","Roadmap","Marketplace"}','product',3800,4.8,29,98,true),
('nilufar-rakhimova','Нилуфар Рахимова','Senior UX-дизайнер, ex-Yandex','Senior UX designer, ex-Yandex','Проектирую интерфейсы для финансовых и образовательных сервисов. Разбор портфолио и переход в продуктовый дизайн.','Designing interfaces for fintech and edtech. Portfolio reviews and transition into product design.','UZ','Ташкент','{ru,en,uz}','{"UX research","Design systems","Portfolio review"}','product',3200,5.0,41,142,true),
('temirlan-abenov','Темирлан Абенов','Staff Engineer, распределённые системы','Staff Engineer, distributed systems','Помогаю инженерам расти до senior/staff: системный дизайн, code review, подготовка к интервью в бигтех.','Helping engineers grow to senior/staff: system design, code review, big tech interview prep.','KZ','Астана','{ru,en}','{"System design","Interview prep","Backend"}','tech',5200,4.9,52,187,true),
('gulnara-sadykova','Гульнара Садыкова','Growth-директор, B2C-приложения','Growth director, B2C apps','Запускала перформанс-маркетинг в 5 странах региона. Аналитика воронок, CAC/LTV, каналы привлечения.','Launched performance marketing in 5 regional markets. Funnel analytics, CAC/LTV, acquisition channels.','KG','Бишкек','{ru,en,ky}','{"Performance marketing","CAC/LTV","Analytics"}','marketing',3600,4.7,24,81,true),
('rustam-yuldashev','Рустам Юлдашев','Инвестиционный аналитик, VC-фонд','Investment analyst, VC fund','Оцениваю сделки ранних стадий. Финмодели, дью-дилидженс, подготовка к общению с фондами.','Evaluating early-stage deals. Financial models, due diligence, preparing for fund conversations.','UZ','Ташкент','{ru,en,uz}','{"Financial modeling","Due diligence","Valuation"}','finance',4800,4.8,19,63,true),
('aigerim-nurlanova','Айгерим Нурланова','Карьерный коуч, ICF ACC','Career coach, ICF ACC','Работаю с руководителями и специалистами: смена карьеры, переговоры о зарплате, выгорание, лидерство.','Working with managers and specialists: career change, salary negotiation, burnout, leadership.','KZ','Алматы','{ru,en,kk}','{"Career change","Negotiation","Leadership"}','career',2900,5.0,63,211,true),
('sanjar-komilov','Санжар Комилов','ML-инженер, LLM в проде','ML engineer, LLM in production','Внедряю ML и LLM-решения в бизнес-процессы. От постановки задачи до продакшена и метрик качества.','Shipping ML and LLM solutions into business processes. From problem framing to production and quality metrics.','UZ','Самарканд','{ru,en,uz}','{"LLM","MLOps","Data strategy"}','data',4400,4.9,31,105,true);

-- seed slots: next 10 days, 3 slots per day per mentor
INSERT INTO public.mentor_slots (mentor_id, starts_at, ends_at)
SELECT m.id,
       (date_trunc('day', now()) + (d || ' days')::interval + (h || ' hours')::interval),
       (date_trunc('day', now()) + (d || ' days')::interval + (h || ' hours')::interval + interval '1 hour')
FROM public.mentors m
CROSS JOIN generate_series(1,10) AS d
CROSS JOIN unnest(ARRAY[10,14,18]) AS h;

-- seed reviews
INSERT INTO public.reviews (mentor_id, client_id, author_name, rating, comment)
SELECT m.id, gen_random_uuid(), a.name, a.rating, a.comment
FROM public.mentors m
CROSS JOIN (VALUES
  ('Асель К.', 5, 'Очень структурная сессия, ушла с конкретным планом действий на месяц.'),
  ('Бекзат М.', 5, 'Разобрали мой кейс по деталям, много практических примеров из региона.'),
  ('Мадина Т.', 4, 'Полезно и по делу. Хотелось бы больше времени на вопросы.')
) AS a(name, rating, comment);