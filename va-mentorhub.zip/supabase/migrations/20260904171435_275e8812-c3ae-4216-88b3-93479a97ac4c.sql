CREATE TYPE public.mentor_status AS ENUM ('pending','active','paused');

ALTER TABLE public.mentors
  ADD COLUMN linkedin_url text,
  ADD COLUMN price_30 integer NOT NULL DEFAULT 0,
  ADD COLUMN price_60 integer NOT NULL DEFAULT 0,
  ADD COLUMN status public.mentor_status NOT NULL DEFAULT 'pending';

UPDATE public.mentors
  SET status = CASE WHEN is_published THEN 'active'::public.mentor_status ELSE 'pending'::public.mentor_status END,
      price_60 = price_per_hour,
      price_30 = GREATEST(round(price_per_hour / 2.0)::int, 0);

CREATE OR REPLACE FUNCTION public.sync_mentor_publication()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $fn$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.status IS DISTINCT FROM OLD.status THEN
    NEW.is_published := (NEW.status = 'active');
  ELSIF NEW.is_published IS DISTINCT FROM OLD.is_published THEN
    NEW.status := CASE WHEN NEW.is_published THEN 'active'::public.mentor_status ELSE 'paused'::public.mentor_status END;
  END IF;
  IF NEW.price_60 > 0 THEN
    NEW.price_per_hour := NEW.price_60;
  END IF;
  RETURN NEW;
END;
$fn$;

REVOKE ALL ON FUNCTION public.sync_mentor_publication() FROM public, anon, authenticated;

CREATE TRIGGER mentors_sync_publication
  BEFORE INSERT OR UPDATE ON public.mentors
  FOR EACH ROW EXECUTE FUNCTION public.sync_mentor_publication();