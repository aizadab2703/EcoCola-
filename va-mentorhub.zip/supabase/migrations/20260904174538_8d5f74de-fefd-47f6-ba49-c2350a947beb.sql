ALTER TABLE public.mentors
  ADD COLUMN IF NOT EXISTS short_bio_ru text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS short_bio_en text NOT NULL DEFAULT '';