CREATE UNIQUE INDEX IF NOT EXISTS mentors_email_lower_unique
  ON public.mentors (lower(email))
  WHERE email IS NOT NULL AND email <> '';

COMMENT ON COLUMN public.mentors.email IS 'Mentor contact email used for invitations and Google Calendar attendees.';