ALTER TABLE public.mentor_applications
  ADD COLUMN IF NOT EXISTS job_title text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT 'KG',
  ADD COLUMN IF NOT EXISTS sectors text[] NOT NULL DEFAULT '{}'::text[],
  ADD COLUMN IF NOT EXISTS short_bio text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS avatar_url text,
  ADD COLUMN IF NOT EXISTS linkedin_url text,
  ADD COLUMN IF NOT EXISTS phone text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'KGS',
  ADD COLUMN IF NOT EXISTS price_30 integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS price_60 integer NOT NULL DEFAULT 0;

CREATE POLICY "mentor_application_photo_upload"
ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'mentor-photos' AND (storage.foldername(name))[1] = 'applications');

CREATE POLICY "mentor_application_photo_read"
ON storage.objects FOR SELECT TO anon, authenticated
USING (bucket_id = 'mentor-photos' AND (storage.foldername(name))[1] = 'applications');